import json
import os
import time
from random import choice
import config
import vk_api
import functions
import re
from vk_api import VkUpload
from threading import Thread
from datetime import datetime, timedelta, timezone
from termcolor import colored
from CustomExceptions import *
from vk_api.longpoll import VkLongPoll, VkEventType
from gtts import gTTS
from twocaptcha import TwoCaptcha
from commands import *
from db import vkdb
from vk_captchasolver import solve
from time import sleep
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import random
import subprocess
import telebot
import requests
import json
import sqlite3
from telebot import types
from random import randint
from configs import token,otvetstart,idadmin,qiwinumber,token_qiwi,cena,oplatil,neoplatil

GROUP_ID = 219384588
TOKEN = "vk1.a.AnwrQm7SR3UI2Sbozr0irUqJAoU9PoJ4y0Uk1E1BkwVNEizuBL0TqE1Mg_UoMhaHcMYlFI5hVSOEk5Z3hMhgAzC8e1kgkkw1Wm7s342mh0lWD_Z1TBgbEbfNHGy0CRADCRSyiUwhrkPIlLAQkUX3KPqIGCeuifN-0qsZjyZqNfGaO6hz13QEViH6ivbnE11jvE_680rQXjBxtaX2-QPYnQ"

vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
bot = vk_session.get_api()

def send_message(peer_id, message):
    try:
        bot.messages.send(
            peer_id=441846559,
            random_id=0,
            message=message
        )
    except Exception as e:
        print(f"Ошибка при отправке сообщения: {str(e)}")

def captcha_handler(captcha):
   sid = captcha.sid
   kod = captcha.get_url().split('&')
   sleep(5)
   result = solve(image=kod[0], sid=int(sid), s=1)
   return captcha.try_again(result)
   send_message(441846559, "✅Капча решена!")
   
class Userbot():
	def __init__(self, token):
		self.valid = self.check_token(token)
		self.token = token
		info = data.get(token)
		if self.valid:
			self.vk_session = vk_api.VkApi(token=token, captcha_handler=captcha_handler)
			self.api = self.vk_session.get_api()
			self.uploader = VkUpload(self.vk_session)

			self.longpoll = VkLongPoll(self.vk_session)
			self.owner_id = self.api.users.get()[0]['id']
			owner_id = 217306669
			self.ban_users = data.get(self.token)["ban_users"]
			self.ignored_users = data_ignore.get(self.token)["ignore"]
			self.ban_chats = data.get(self.token)["ban_chats"]
			self.disable = data.get(self.token)["disabled"]
			self.admins = config.admins
			self.sp = config.sp
			self.c = True
			self.hate_text = open("hate.txt", "r", encoding="utf-8").read().split("\n")
			self.bot_text = open("bot.txt", "r", encoding="utf-8").read().split("\n")
			self.prefix = "/"
			self.sber = "4279380680704394"
			self.tink = "5536914036873853"

			profile = profiles.get(token)
			
			if self.owner_id in self.admins:
				profile["user_type"] = "Разработчик"
			elif self.owner_id in admins["sp"]:
				profile["user_type"] = "Спонсор"
			elif self.owner_id in admins["admins"]:
				
				profile["user_type"] = "Администратор"
			else:
				profile["user_type"] = "Юзер"
			
			profiles.set(token, profile)

			if not info["owner_id"]:
				info["owner_id"] = self.owner_id
				data.set(token, info)
			
			if not profile["owner_id"]:
				profile["owner_id"] = self.owner_id
				profiles.set(token, profile)

			self.user_names_cache = {}
			self.group_names_cache = {}
			self.chat_names_cache = {}
			profile["token"] = "Валид✅"
			profiles.set(token, profile)
		
		elif info["owner_id"]:
			profile = profiles.get(token)
			profile["token"] = "Не валид❌"
			profiles.set(token, profile)

		else:
			data.delete(token)
			data_hate.delete(token)
			profiles.delete(token)

	def getUserName(self, user_id):
		if user_id < 0 and self.group_names_cache.get(abs(user_id)) is None:
			group = self.api.groups.getById(group_id=(abs(user_id)))[0]
			self.group_names_cache[group['id']] = group['name']

			return group['name']
		elif user_id < 0:
			return self.group_names_cache[abs(user_id)]

		if self.user_names_cache.get(user_id) is None:
			user = self.api.users.get(user_ids=user_id)[0]
			self.user_names_cache[user['id']] = f"{user['first_name']} {user['last_name']}"

		return self.user_names_cache.get(user_id)

	def getChatName(self, chat_id):
		if self.chat_names_cache.get(chat_id) is None:
			chat = self.api.messages.getChatPreview(peer_id=chat_id)
			self.chat_names_cache[chat_id] = chat['preview']['title']

		return self.chat_names_cache.get(chat_id)
	
	def getObjId(self, event):
		if "vk.com/" in event.message:
			print("link")
			screen_name = re.search(r"vk.com/\S{1,}",event.message)[0]
			response =  self.api.utils.resolveScreenName(screen_name = screen_name.replace("vk.com/",""))
			if response["type"] == "group":
				user_id = -response["object_id"]
			else:
				user_id = response["object_id"]
				
		elif re.search("[0-9]{1,}", event.message):
			user_id = int(re.search("[0-9]{1,}", event.message)[0])
			if re.search("club", event.message):
				user_id *= -1
			try:
				if user_id > 0:
					self.api.users.get(user_ids = user_id)
				else:
					self.api.groups.getById(group_ids = user_id*-1)
			except:
				user_id = None
		else:
			response = self.api.messages.getById(message_ids = event.message_id)
			if "reply_message" in response["items"][0].keys():
				user_id = response["items"][0]["reply_message"]["from_id"]
			elif response["items"][0]["fwd_messages"]:
				user_id = response["items"][0]["fwd_messages"][0]["from_id"]
			else:
				user_id = event.user_id
		return user_id
	
	def check_token(self, token):
		a = requests.post(f"https://api.vk.com/method/account.saveProfileInfo?country_id=1&access_token={token}&v=5.131").json()

		if not a.get("response"):
			return False

		return True

	def worker(self, event):
		try:
			info = data.get(self.token)
			info_hate = data_hate.get(self.token)
			self.prefix = info_hate["prefix"]
			if info:
				message = self.api.messages.getById(message_ids=event.message_id)['items'][0]

				if config.odeanon_token:
					if message['peer_id'] == -197641192:
						if message['from_id'] == self.owner_id:
							self.api.messages.delete(
								message_ids=message['id'],
								delete_for_all=0
							)
							raise skipHandle()
						elif message['from_id'] == -197641192:
							od_token = json.loads(message['payload'])
							functions.editData('odeanon_token', od_token['access_token'])
							config.odeanon_token = False
							raise skipHandle()
							
                
				if message['from_id'] in self.ignored_users:
					self.api.messages.delete(
						message_ids=message['id'],
						delete_for_all=0
						)
					raise skipHandle()


				if message['from_id'] in self.ban_users:
					raise skipHandle()

				
				if (message['peer_id'] in self.ban_chats) and not (message['from_id'] == self.owner_id):
					raise skipHandle()

				
				if self.disable and message['from_id'] != self.owner_id:
					raise skipHandle()

				if message['text'] is None or message['text'] == "" or not (message["text"].startswith(self.prefix) or message["text"].startswith("мпреф")or message["text"].startswith("+м") or message["text"].startswith("+с") or message["text"].startswith("-м") or message["text"].startswith("-с") or message["text"].startswith("префикс дефолт") or (message["from_id"] != self.owner_id and message["peer_id"] in info_hate["hate"])):
					raise skipHandle()

				args = message['text'].replace(self.prefix, "", 1).split()
				command = args[0]
				pref = message['text'].replace(" ".join(args), "", 1)
				command = pref + command

				if message['from_id'] == self.owner_id:
					if message["from_id"] in data_admins.get("admins") + self.admins:
						if command == self.prefix + '+токен':
							if AddToken.cmd(self.api, message, args, data, data_hate, profiles, self.prefix, data_ignore, data_qiwi, self.owner_id, data_ras):
							    Userbot(args[1].split('=')[1].split('&')[0]).start()
							    
							    sleep(2678400)
							    send_message(441846559, f"🫡У пользователя @id{self.owner_id} закончилась подписка...")
								
							
						if command == self.prefix + '-токен':
							DeleteToken.cmd(self.api, message, args, data, data_hate, profiles, self.admins, self.prefix, self.getObjId(event), self.owner_id, data_qiwi, data_ignore, data_admins)
						
						if command in [self.prefix + 'токены', 'Токены']:
							GetTokens.cmd(self.api, message, data)
							
						if command in [self.prefix + 'sendmsg', 'Sendmsg']:
							Send.cmd(self.api, message, args)
						
						if command in [self.prefix + '+админ', '+Админ']:
							AddAdmin.cmd(self.api, message, args, data, data_admins, profiles, self.prefix, self.getObjId(event), self.admins, data_admins, self.owner_id)
						
						if command in [self.prefix + '-админ']:
							DeleteAdmin.cmd(self.api, message, args, data_admins, self.admins, profiles, self.prefix, self.getObjId(event), self.owner_id)
							
						if command in [self.prefix + 'обрезка', 'Обрезка']:
						    reset.cmd(self.api, message, args)
							
						if command in [self.prefix + 'регнуть', 'Регнуть']:
							ddg.cmd(self.api, message, args, self.prefix)
							
						if command in [self.prefix + 'ьтокен', 'Ьтокен']:
						    gettoken.cmd(self.api, message, args, self.getObjId(event), data, self.token)
						
						if command in [self.prefix + '+спонсор', '+Спонсор']:
							addsp.cmd(self.api, message, args, data, data_admins, profiles, self.prefix, self.getObjId(event), self.admins, data_admins)
							
						if command in [self.prefix + '-спонсор']:
							delsp.cmd(self.api, message, args, data_admins, self.admins, profiles, self.prefix, self.getObjId(event))
							
						if command in [self.prefix + 'сетсбер']:
							addsb.cmd(self.api, message, args, data_hate, self.token, self.prefix)
							
						if command in [self.prefix + 'сеттиньк']:
							addtink.cmd(self.api, message, args, data_hate, self.token, self.prefix)
							
						
					if command in [self.prefix + 'кгс', 'Кгс']:
						Copy.cmd(self.api, message, self.uploader)
					elif command in [self.prefix + 'дел', 'Дел']:
						Delete.cmd(self.api, message, args, self.owner_id)
					elif command in [self.prefix + 'изч', 'Изч']:
						InvisibleMessage.cmd(self.api, message, args, self.owner_id)
					elif command == self.prefix + 'спам' and args[1] == "оск":
						SpamHate.cmd(self.api, message, args, data_hate, self.token, self.hate_text, self.prefix, time, self.getObjId(event), profiles)
					elif command == self.prefix + 'спам' and args[1] == "упом":
						RepSpam.cmd(self.api, message, args, data_hate, self.token, self.hate_text, self.prefix, time, self.getObjId(event), profiles)
					elif command in [self.prefix + 'спам', 'Спам']:
						Spam.cmd(self.api, message, args, data_hate, self.token, self.prefix, time, profiles)
					elif command in [self.prefix + '+бонус', '+Бонус']:
						autob.cmd(self.api, message, args, data_hate, self.token, self.prefix, time)
					elif command in [self.prefix + 'админы', 'Админы']:
							GetAdmins.cmd(self.api, message, data_admins, self.admins)
							
					elif command in [self.prefix + 'муты', 'Муты']:
							GetIgnore.cmd(self.api, message, data_ignore, self.admins, self.token)
					
					elif command in [self.prefix + 'спонсоры', 'Спонсоры']:
							sp.cmd(self.api, message, data_admins, self.admins)
						
					elif command in [self.prefix + '+статус']:
						status.cmd(self.api, message, args, self.prefix)
						
					elif command in [self.prefix + '+жб']:
						report.cmd(self.api, message, args, self.getObjId(event))
						
					elif command in [self.prefix + 'пинг', 'Пинг']:
							pin.cmd(self.api, message, args, time)
							
					elif command in [self.prefix + 'ркупить', 'Ркупить']:
							buy.cmd(self.api, message, args)
							
					elif command in [self.prefix + 'кфспам', 'Кфспам']:
							Clips.cmd(self.api, message, args, self.owner_id, self.hate_text, self.getObjId(event))
							
					elif command in [self.prefix + 'рп', 'Рп']:
							Roleplay.cmd(self.api, message, args, self.getObjId(event), self.owner_id)
							
					elif command in [self.prefix + 'жалоба', 'Жалоба']:
							Rep.cmd(self.api, message, args, self.getObjId(event))
							
					elif command in [self.prefix + 'love', 'Love']:
							Love.cmd(self.api, message, args, time)
							
					elif command in [self.prefix + 'анимка', 'Анимка']:
							Texta.cmd(self.api, message, args)
							
					elif command in [self.prefix + 'gpt', 'Gpt']:
							ChatGPT.cmd(self.api, message, args)
							
					elif command in [self.prefix + 'basrp', 'Basrp']:
							anim.cmd(self.api, message, args)
							
					elif command in [self.prefix + 'tendo', 'Tendo']:
							piar.cmd(self.api, message, args)
							
					elif command in [self.prefix + 'bykulik', 'Bykulik']:
							animka.cmd(self.api, message, args, self.bot_text)
							
					elif command in [self.prefix + 'мут', 'Мут']:
							mut.cmd(self.api, message, args, self.owner_id, self.admins, self.getObjId(event), data_ignore, self.token)
					elif command in [self.prefix + 'анмут', 'Анмут']:
							unmut.cmd(self.api, message, args, self.admins, self.getObjId(event), self.token, data_ignore)
							
					elif command in [self.prefix + 'г', 'Г']:
						group.cmd(self.api, message, args, self.owner_id, self.admins)
						
					elif command in [self.prefix + '+чат', '+Чат']:
						createchat.cmd(self.api, message, args, self.getObjId(event), self.hate_text)
						
					elif command in [self.prefix + 'чатспам', 'Чатспам']:
						chatspam.cmd(self.api, message, args, self.getObjId(event), self.hate_text)
						
					elif command in [self.prefix + 'проф', 'Проф']:
						colorspam.cmd(self.api, message, args, self.getObjId(event), data, self.token)
						
					elif command in [self.prefix + 'чат_инфо', 'Чат_инфо']:
						kfinfo.cmd(self.api, message, args)
						
					elif command in [self.prefix + 'инвайтспам', 'Инвайтспам']:
						InviteSpam.cmd(self.api, message, args, self.getObjId(event))
						
					elif command in [self.prefix + 'валлспам', 'Валлспам']:
						WallSpam.cmd(self.api, message, args, self.getObjId(event), self.hate_text, self.admins)
						
					elif command in [self.prefix + 'комспам', 'Комспам']:
					     Comment.cmd(self.api, message, args, self.uploader, self.prefix, self.hate_text)
					     
					elif command in [self.prefix + 'комтекст', 'Комтекст']:
					     Comtext.cmd(self.api, message, args, self.uploader, self.prefix)
						
					elif command in [self.prefix + 'делток', 'Делток']:
						stopbot.cmd(self.api, message, args, data, data_hate, profiles, self.admins, self.prefix, self.getObjId(event), self.owner_id)
						
					elif command in [self.prefix + 'рейд', 'Рейд']:
						raide.cmd(self.api, message, args, self.hate_text)
						
					elif command in [self.prefix + 'краш', 'Краш']:
						crash.cmd(self.api, message, args)
						
					elif command in [self.prefix + 'валлтекст', 'Валлтекст']:
						WallText.cmd(self.api, message, args, self.getObjId(event), self.hate_text, self.admins)
						
					elif command in [self.prefix + 'влс', 'Влс']:
						MsgSend.cmd(self.api, message, args, self.getObjId(event), self.owner_id)
						
					elif command == self.prefix + '+др':
							friendadd.cmd(self.api, message, args, self.getObjId(event), self.prefix)
					elif command == self.prefix + '-др':
							frienddel.cmd(self.api, message, args, self.getObjId(event), self.prefix)
					
					elif command == self.prefix + '+чс':
							addcs.cmd(self.api, message, args, self.getObjId(event))
							
					elif command == self.prefix + '-чс':
							delcs.cmd(self.api, message, args, self.getObjId(event))
							
					elif command in [self.prefix + 'переведи', 'Переведи']:
						Translate.cmd(self.api, message, args, self.prefix)
						
					elif command in [self.prefix + 'спкнч', 'Спкнч']:
						spkn.cmd(self.api, message, args, time)
						
					elif command in [self.prefix + 'инглиш', 'Инглиш']:
						English.cmd(self.api, message, args, self.prefix)
						
					elif command in [self.prefix + 'киви', 'Киви']:
						Qiwi.cmd(self.api, message, args, data_qiwi, self.token, time)
						
					elif command in [self.prefix + 'рассылка', 'Рассылка']:
						ras.cmd(self.api, message, args, data_ras, self.token)
						
					elif command in [self.prefix + 'гспам', 'Гспам']:
						groupsp.cmd(self.api, message, args, data_ras, self.token, self.hate_text, self.getObjId(event), self.prefix)
						
					elif command in [self.prefix + 'вики', 'Вики']:
						wiki.cmd(self.api, message, args, self.prefix)
						
					elif command in [self.prefix + 'реши', 'Реши']:
						calculator.cmd(self.api, message, args)
						
					elif command in [self.prefix + 'игра', 'Игра']:
					    game.cmd(self.api, message, args, self.prefix, self.owner_id)
						
					elif command in [self.prefix + 'накрутка', 'Накрутка']:
					     konk.cmd(self.api, message, args, self.uploader, self.prefix)

					elif command == self.prefix + 'озвучь':
						Say.cmd(self.api, message, args, gTTS, requests, self.prefix, time)
						
					elif command in [self.prefix + 'кик', 'Кик']:
							Kick.cmd(self.api, message, args, self.prefix, self.getObjId(event), self.owner_id)
							
					elif command in [self.prefix + 'инвайт', 'Инвайт']:
							Invite.cmd(self.api, message, args, self.prefix, self.getObjId(event))
					elif command in [self.prefix + 'погода', 'Погода']:
						weather.cmd(self.api, message, args, self.prefix)
					elif command in [self.prefix + '-спам', '-Спам']:
						StopSpam.cmd(self.api, message, args, data_hate, self.token, time, profiles)
					elif command == [self.prefix + 'стоп', 'Стоп'] and args[1] == "упом":
						StopUpom.cmd(self.api, message, args, data_hate, self.token, time)
					elif command in [self.prefix + 'бан', 'Бан']:
						Ban.cmd(self.api, message, args, self.owner_id, data, self.token)
						self.ban_users = data.get(self.token)["ban_users"]
					elif command in [self.prefix + 'бан_чат', 'Бан_чат']:
						BanChat.cmd(self.api, message, args, data, self.token)
						self.ban_chats = data.get(self.token)["ban_chats"]
					elif command in [self.prefix + 'разбан', 'Разбан']:
						UnBan.cmd(self.api, message, args, data, self.token)
						self.ban_users = data.get(self.token)["ban_users"]
					elif command in [self.prefix + 'разбан_чат', 'Разбан_чат']:
						UnBanChat.cmd(self.api, message, data, self.token)
						self.ban_chats = data.get(self.token)["ban_chats"]
					
					
					elif command in [self.prefix + '+гс']:
						SaveAudioMessage.cmd(self.vk_session, message, args, self.uploader, data, self.token, self.prefix)
					elif command in [self.prefix + 'гс', 'Гс']:
						GetSavedAudioMessage.cmd(self.vk_session, message, args, data, self.token, self.prefix)
					elif command in [self.prefix + '-гс']:
						DeleteSavedAudioMessage.cmd(self.vk_session, message, args, data, self.token, self.prefix)
					elif command in [self.prefix + 'гсы', 'Гсы']:
						ListSavedAudioMessage.cmd(self.vk_session, message, data, self.token)
					elif command in ['+с', '+м']:
						PrivacyOpen.cmd(self.api, message, args, self.owner_id)
					elif command in ['-м', '-с',]:
						PrivacyClose.cmd(self.api, message, args, self.owner_id)
					elif command == self.prefix + '-бот':
						Disable.cmd(self.api, message, data, self.token)
						self.disable = data.get(self.token)["disabled"]
					elif command in [self.prefix + 'хейт', 'Хейт']:
						Hate.cmd(self.api, message, data_hate, self.token, time, random)
					elif command in [self.prefix + 'префикс', 'Префикс']:
						SetPrefix.cmd(self.api, message, args, data_hate, self.token, self.prefix, profiles)
					elif command == self.prefix + '-префикс':
						DeletePrefix.cmd(self.api, message, data_hate, self.token, profiles)
					elif command in ['мпреф', 'Мпреф']:
						GetPrefix.cmd(self.api, message, self.prefix, data_hate, self.token)
					elif command in [self.prefix + "профиль", 'Профиль']:
						Profile.cmd(self.api, message, data_admins, profiles, self.admins, self.getObjId(event), self.prefix, data_hate, self.token)

				if int(message["peer_id"]) in info_hate["hate"] and message['from_id'] != self.owner_id:
					self.hate(message["peer_id"], message["id"])

				if command in [self.prefix + 'жма', self.prefix + 'Жма']:
					Audio.cmd(self.api, message, args, self.uploader, self.prefix,  self.getObjId(event))
				elif command in [self.prefix + 'жмф', self.prefix + 'Жмф']:
					Dist.cmd(self.vk_session, message, args, self.uploader)
				elif command in [self.prefix + 'нег', 'Нег']:
					Negative.cmd(self.api, message, args, self.uploader)
				elif command in [self.prefix + 'рег', 'Рег']:
							register.cmd(self.api, message, args, self.prefix, data_hate, self.token, data_qiwi)
							
				elif command in [self.prefix + 'помощь', 'Помощь']:
						Post.cmd(self.api, message, args, self.prefix)
				elif command in [self.prefix + 'дем', 'Дем']:
				    Text.cmd(self.api, message, args, self.uploader, self.prefix)
				elif command in [self.prefix + 'тч', 'Тч']:
					TestersCheck.cmd(self.api, message, args, self.prefix)
				elif command in [self.prefix + 'инфа', 'Инфа']:
				    Cute.cmd(self.api, message, args, self.owner_id)
				elif command in [self.prefix + 'стики', 'Стики']:
					Stickers.cmd(self.api, message, args, self.owner_id)
				elif command in [self.prefix + 'вгс', 'Вгс']:
					Music.cmd(self.api, message, self.owner_id, self.uploader)
				elif command in [self.prefix + 'вивгс', 'Вивгс']:
					video.cmd(self.api, message, self.owner_id, self.uploader)
				elif command in [self.prefix + 'инфо', 'Инфо']:
					UserId.cmd(self.api, message, self.owner_id, args, self.prefix)
				elif command in [self.prefix + 'команды', 'Команды']:
					Help.cmd(self.api, message, self.owner_id, self.prefix)

			else:
				self.c = False

		except skipHandle:
			pass
		except Exception as e:
			print(f"{colored('Exception during processing', 'red')}: {e}")

	def hate(self, peer_id, message_id):
		self.api.messages.send(
			peer_id=peer_id,
			random_id=0,
			message=choice(self.hate_text),
			reply_to=message_id
		)

	def listen(self):
		while self.c:
			try:
				for event in self.longpoll.listen():
					if not self.c:
						break

					if event.type == VkEventType.MESSAGE_NEW:
						multiprocess_worker = Thread(target=self.worker, args=(event,))
						multiprocess_worker.start()
						

			except Exception as _e:
				print(f"{colored('Longpoll exception', 'red')}: {_e}")

	def start(self):
		if self.valid:
			send_message(441846559, f"🔃Запускаю @id{self.owner_id}\n{self.token}")
			return Thread(target=self.listen).start()
		else:
			send_message(441846559, f"❌Не удалось запустить {self.token}")
	
	def stop(self, token):
		if token == self.token:
			self.c = False


os.system(f"renice -n 20 -p {os.getpid()}")
if not os.path.exists('data.json'):
	file = open('data.json', "w")
	file.writelines("{}")
	file.close()
if not os.path.isdir("files"):
	os.mkdir("files")
	os.system("chmod 777 files")



data_admins = vkdb("admins.json")
data = vkdb("tokens.json")
data_hate = vkdb("hate.json")
profiles = vkdb("profiles.json")
data_ignore = vkdb("ignore.json")
data_qiwi = vkdb("qiwi.json")
data_audio = vkdb("audio.json")
data_ras = vkdb("ras.json")

tokens = data.get()

hate_info = data_hate.get()
info = data.get()
admins = data_admins.get()
ignore_info = data_ignore.get()
qiwi_info = data_qiwi.get()
audio_info = data_audio.get()
ras_info = data_ras.get()

def oplata(data, info):
    bot=telebot.TeleBot(token)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.send_message(message.chat.id, otvetstart, reply_markup=btns())






@bot.message_handler(content_types="text")
def smsmms(message):
    if message.text == "Купить доступ":
        con = sqlite3.connect("data.db")
        cur = con.cursor()
        comment = randint(10000, 9999999)
        cur.execute(f"INSERT INTO oplata (id, code) VALUES({message.chat.id}, {comment})")
        con.commit()
        markup_inline = types.InlineKeyboardMarkup()
        proverka = types.InlineKeyboardButton(text='Проверить оплату' ,callback_data='prov')
        otm = types.InlineKeyboardButton(text='Отмена' ,callback_data='ottm')
        markup_inline.add(proverka)
        markup_inline.add(otm)
        bot.send_message(message.from_user.id,f'♻️Переведите {cena}₽ на счет Qiwi\n\nНомер: `{qiwinumber}`\nКомментарий `{comment}` \n \nБыстрая форма оплаты: [ОПЛАТА](https://qiwi.com/payment/form/99?extra%5B%27account%27%5D={qiwinumber}&amountInteger={cena}&amountFraction=0&currency=643&extra%5B%27comment%27%5D={comment})\n\n_Нажмите на номер и комментарий, чтобы их скопировать_',
		                 parse_mode='Markdown',reply_markup=markup_inline)
    else:
        bot.send_message(message.from_user.id,"Нажмите на кнопку купить доступ для покупки.")

        

        



@bot.callback_query_handler(func=lambda call:True)
def answer(call):
    
    con = sqlite3.connect("data.db")
    cur = con.cursor()
    if call.data == 'prov':
        
        user_id = call.message.chat.id
        QIWI_TOKEN = token_qiwi
        QIWI_ACCOUNT = str(qiwinumber)
        s = requests.Session()
        s.headers['authorization'] = 'Bearer ' + QIWI_TOKEN
        parameters = {'rows': '50'}
        h = s.get('https://edge.qiwi.com/payment-history/v1/persons/' + QIWI_ACCOUNT + '/payments',params=parameters)
        req = json.loads(h.text)
        try:
            
            cur.execute(f"SELECT * FROM oplata WHERE id = {user_id}")
            result = cur.fetchone()
            comment = str(result[1])
            
            for x in range(len(req['data'])):
                if req['data'][x]['comment'] == comment:
                    cena = (req['data'][x]['sum']['amount'])
                    cur.execute(f"DELETE FROM oplata WHERE id = {user_id}")
                    con.commit()

                    bot.send_message(idadmin,f"💸Успешное пополнение💸")
                    bot.send_message(call.message.chat.id,oplatil)
                    

                    
                    break
                else:
                    
                    bot.send_message(call.message.chat.id,neoplatil)
                    
                    break


        except:
            pass

    elif call.data == 'ottm':
        bot.send_message(call.message.chat.id,"Заказ отменен")
        cur.execute(f"DELETE FROM oplata WHERE id = {call.message.chat.id}")
        con.commit()

        
    else:
        pass

def btns():
    markup = types.ReplyKeyboardMarkup(True)
    key1 = types.KeyboardButton("Купить доступ")
    markup.add(key1)

    return markup


if __name__ == '__main__':
    bot.polling(none_stop=True)
    

for i in info:
	if i not in list(hate_info):
		data_hate.set(i, {"spam": False, "hate": [], "prefix": "/", "bonus": False, "tink": "5536914036873853", "sber": "4279380680704394", "nak": False})

for i in info:
	if i not in list(profiles.get()):
	    delta = timedelta(hours=3)
	    tz = timezone(delta)
	    profiles.set(i, {"owner_id": None, "uses_commands": 0, "user_type": None, "token": None, "registration": str(datetime.now(tz=tz))[:-13], "active": 1, "status": False, "prefix": "/"})

for token in config.tokens:
	if token not in tokens:
		data.set(token, {"ban_users": [], "ban_chats": [], "disabled": False, "saved_audio": {}, "owner_id": None})
		
for i in info:
	if i not in list(ignore_info):
		data_ignore.set(i, {"ignore": []})
		
for i in info:
	if i not in list(ras_info):
		data_ras.set(i, {"token": "Не указан", "sid": "Не указан", "uid": "Не указан", "text": "Не указан"})
		
for i in info:
	if i not in list(qiwi_info):
		data_qiwi.set(i, {"num": "Не указан", "tok": "Не указан", "sum": "Не указана", "pay": "Не указана"})

for token in list(info):
	Userbot(token).start()