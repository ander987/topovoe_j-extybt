import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType

GROUP_ID = 219384588
TOKEN = "vk1.a.AnwrQm7SR3UI2Sbozr0irUqJAoU9PoJ4y0Uk1E1BkwVNEizuBL0TqE1Mg_UoMhaHcMYlFI5hVSOEk5Z3hMhgAzC8e1kgkkw1Wm7s342mh0lWD_Z1TBgbEbfNHGy0CRADCRSyiUwhrkPIlLAQkUX3KPqIGCeuifN-0qsZjyZqNfGaO6hz13QEViH6ivbnE11jvE_680rQXjBxtaX2-QPYnQ"
vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
api = vk_session.get_api()
subscribers = api.groups.getMembers(group_id=GROUP_ID, v='5.131')['items']
for subscriber in subscribers:
    try:
        api.messages.send(
            peer_id=subscriber,
            random_id=0,
            message=f"Всем привет! запускаем акцию совместно с [https://vk.com/paradoxlply|ParadoxLP]\nПервые 100 человек могут приобрести сразу два бота навсегда всего за 150₽\nДля покупки писать [id587742332|@presentdevilmybody] или [id441846559|@Tendo]"
            )
        api.messages.send(
            peer_id=441846559,
            random_id=0,
            message=f"✅Сообщение отправлено пользователю @id{subscriber}"
            )
    except Exception as e:
        api.messages.send(
            peer_id=441846559,
            random_id=0,
            message=f"❌Ошибка при отправке сообщения пользователю @id{subscriber}: {e}"
            )