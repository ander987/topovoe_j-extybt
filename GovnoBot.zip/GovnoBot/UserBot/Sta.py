import asyncio
import sys
import os
import psutil
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from vk_api.utils import get_random_id
import json

GROUP_ID = 219384588
TOKEN = "vk1.a.AnwrQm7SR3UI2Sbozr0irUqJAoU9PoJ4y0Uk1E1BkwVNEizuBL0TqE1Mg_UoMhaHcMYlFI5hVSOEk5Z3hMhgAzC8e1kgkkw1Wm7s342mh0lWD_Z1TBgbEbfNHGy0CRADCRSyiUwhrkPIlLAQkUX3KPqIGCeuifN-0qsZjyZqNfGaO6hz13QEViH6ivbnE11jvE_680rQXjBxtaX2-QPYnQ"

vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
vk = vk_session.get_api()

SCRIPTS = [
    'bot.py',
    'main.py',
    'ma.py'
]

MAX_THREADS = 3

async def restart_script(script):
    print(f'Перезапускаю {script}')
    
    vk.messages.send(
        peer_id=441846559,
        random_id=0,
        message=f"⚙️Process {script} killed, starting..."
    )
    
    vk.messages.send(
        peer_id=441846559,
        random_id=0,
        message=f"✅Process {script} started!"
    )

    for sc in SCRIPTS:
        vk.messages.send(
            peer_id=GROUP_ID,
            random_id=0,
            message=f"{sc}: PID {processes[sc].pid}"
        )
    
    processes[script].terminate()  # Остановить процесс
    processes[script] = await asyncio.create_subprocess_exec(sys.executable, script)  # Перезапустить скрипт

async def main():
    waiters = []
    processes = {}

    for sc in SCRIPTS:
        p = await asyncio.create_subprocess_exec(sys.executable, sc)
        print('Запускаю', sc)
        vk.messages.send(
            peer_id=441846559,
            random_id=0,
            message=f"✅Starting {sc}"
        )
        processes[sc] = p
        waiters.append(asyncio.create_task(waiter(sc, p)))

    keyboard = {
        "one_time": False,
        "buttons": [
            [
                {
                    "action": {
                        "type": "text",
                        "payload": "{\"button\": \"1\"}",
                        "label": "⚙️️перезапустить bot.py"
                    },
                    "color": "secondary"
                }
            ],
            [
                {
                    "action": {
                        "type": "text",
                        "payload": "{\"button\": \"2\"}",
                        "label": "⚙️️перезапустить main.py"
                    },
                    "color": "secondary"
                }
            ],
            [
                {
                    "action": {
                        "type": "text",
                        "payload": "{\"button\": \"3\"}",
                        "label": "⚙️️перезапустить ma.py"
                    },
                    "color": "secondary"
                }
            ]
        ]
    }
    keyboard = json.dumps(keyboard, ensure_ascii=False).encode('utf-8')
    keyboard = str(keyboard.decode('utf-8'))

    for event in longpoll.listen():
        if event.type == VkBotEventType.MESSAGE_NEW and event.message.get('text'):
            text = event.message['text'].lower()
            
            if text.startswith('⚙️️перезапустить '):
                script_name = text[len('⚙️️перезапустить '):]
                if script_name in SCRIPTS:
                    print(f"Перезапуск {script_name}")
                    vk.messages.send(
                        peer_id=441846559,
                        random_id=0,
                        message=f"🔃Killed process «{script_name}»..."
                    )
                    await restart_script(script_name)
                else:
                    vk.message.send(
                        peer_id=441846559,
                        random_id=0,
                        message=f"❌Process {script_name} not found"
                    )

    for sc, p in processes.items():
        if p.returncode is not None:
            await restart_script(sc)
            await asyncio.sleep(5)
            try:
                await asyncio.gather(*waiters)
            except KeyboardInterrupt:
                print("Interrupted")
                
                for p in psutil.process_iter():
                    try:
                        if p.name() == "python":
                            p.terminate()
                    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                        pass

                for p in psutil.process_iter():
                    try:
                        if p.name() == "python":
                            p.wait(1)
                    except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                        pass

if __name__ == "__main__":
    asyncio.run(main())