import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType

# Авторизация
vk_session = vk_api.VkApi(token='vk1.a.3vQKW_wF1v7dWn4khyrVJrXmcveYb9abiK7gZ6W6ZU02O-IP2nm3Vjtz8K3B7EZRwezqc-_3u-9OE7Scwep7LidPtGRBDMBFi514BEYhVRnfmfjtIJTcFZDcMhB0BojrcZow-QkwQAZHQ99PHoHYTEWdZluW6BLnq-6YCIhsP-6VTSdjUh2fpqdEK8gtCdlpzwstWkFnWX-3pggv7hvOmA')
vk = vk_session.get_api()

# Получение экземпляра longpoll
longpoll = VkBotLongPoll(vk_session, '219384588')

# Функция для отправки сообщений
def send_message(peer_id, message):
    vk.messages.send(peer_id=peer_id, message=message, random_id=0)

# Основной цикл
for event in longpoll.listen():
    if event.type == VkBotEventType.MESSAGE_NEW and event.obj.message['peer_id'] > 2000000000:
        # Если сообщение новое и пришло в личку сообщества
        message = event.obj.message['text']
        peer_id = event.obj.message['peer_id']
        
        openai.api_key = "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"
        
        response = openai.Completion.create(
            model="text-davinci-003",
            prompt=message,
            temperature=0.9,
            max_tokens=4000,
            top_p=1,
            frequency_penalty=0.0,
            presence_penalty=0.6,
        )
        otv = response['choices'][0]['text']

        # Отправляем ответ
        send_message(peer_id, f"{otv}")