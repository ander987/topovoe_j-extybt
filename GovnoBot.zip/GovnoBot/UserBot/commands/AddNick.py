def cmd(vk, message, args, data, token, user_id):
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❌Правильное использование команды: +ник [ник]"
            )
    elif len(args) >= 2:
        info = data.get(token)
        text = " ".join(args[1:])
        info["nick"] = text
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, установила ник {text}"
            )