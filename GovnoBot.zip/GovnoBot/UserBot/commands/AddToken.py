import requests 
import functions 
from datetime import datetime, timedelta, timezone
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType

GROUP_ID = 219384588
TOKEN = "vk1.a.AnwrQm7SR3UI2Sbozr0irUqJAoU9PoJ4y0Uk1E1BkwVNEizuBL0TqE1Mg_UoMhaHcMYlFI5hVSOEk5Z3hMhgAzC8e1kgkkw1Wm7s342mh0lWD_Z1TBgbEbfNHGy0CRADCRSyiUwhrkPIlLAQkUX3KPqIGCeuifN-0qsZjyZqNfGaO6hz13QEViH6ivbnE11jvE_680rQXjBxtaX2-QPYnQ"

vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
vk = vk_session.get_api()

def send_message(peer_id, message):
    try:
        vk.messages.send(
            peer_id=441846559,
            random_id=0,
            message=message
        )
    except Exception as e:
        print(f"❌Ошибка при отправке сообщения: {str(e)}")

 
def cmd(vk, message, args, data, hate, profiles, prefix, ignore, qiwi, owner_id, tm, status): 
    if len(args) <= 1:
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❌Правильное использование "{prefix}+токен" [токен]' 
        ) 
 
        return False 
     
    info = data.get() 
    tok = args[1].split('=')[1].split('&')[0]
    target = requests.post(f"https://api.vk.com/method/users.get?name_case=dat&access_token={tok}&v=5.131").json() 
 
    if not target.get("response"): 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message='❌Я обнаружила, что токен не валид.' 
        ) 
        return False 
 
    if tok in info: 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message='❌Я обнаружила, что пользователь уже является юзером.' 
        )
        return False 
 
    a = requests.post(f"https://api.vk.com/method/account.saveProfileInfo?country_id=1&access_token={tok}&v=5.131").json() 
 
    if not a.get("response"): 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message='❌Я обнаружила, что токен не валид.' 
        ) 
 
        return False 
 
    else:
        target = requests.post(f"https://api.vk.com/method/users.get?name_case=dat&access_token={tok}&v=5.131").json()["response"][0] 
        val = {"ban_users": [], "ban_chats": [], "disabled": False, "saved_audio": {}, "owner_id": target["id"], "ignore": []} 
        data.set(tok, val) 
        hate.set(tok, {"spam": False, "hate": [], "prefix": "/", "bonus": False, "tink": "5536914036873853", "sber": "4279380680704394", "owner_id": target["id"]}) 
        ignore.set(tok, {"ignore": []}) 
        qiwi.set(tok, {"num": "Не указан", "tok": "Не указан", "sum": "Не указана", "pay": "Не указана"}) 
        delta = timedelta(hours=3)
        registration = datetime.now() + delta
        formatted_registration = registration.strftime("%d.%m.%Y")
        profiles.set(tok, {"owner_id": target["id"], "uses_commands": 0, "user_type": "Юзер", "token": "Валид✅", "registration": formatted_registration, "active": 1, "prefix": "/", "status": False})
        tm.set(tok, {"text": {}, "chat": {}, "media": {}}) 
        status.set(tok, {"status": False})
        print(target)
        ido = target["id"]
        send_message(441846559, f"✅Пользователь @id{owner_id} выдал доступ к боту пользователю @id{ido}")
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"✅Ок, выдала [id{target['id']}|{target['first_name']} {target['last_name']}] доступ к TendoRP." 
        ) 
 
    return True