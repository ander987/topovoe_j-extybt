from time import sleep
def cmd(vk, message, args, prefix, owner_id):
    vk.messages.send(
        peer_id=message['peer_id'],
        reply_to=message['id'],
        random_id=0,
        message=f"{prefix}спам упом"
        )
    sleep(30)
    vk.messages.send(
        peer_id=message['peer_id'],
        message_id=message['id'],
        random_id=0,
        message=f"{prefix}-спам"
        )
        
    if message["id"] == owner_id:
        vk.messages.send(
        peer_id=message['peer_id'],
        message_id=message['id'],
        random_id=0,
        message=f"Пикать Алл плохо"
        )
        
    