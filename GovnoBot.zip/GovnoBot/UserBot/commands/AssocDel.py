import config
import functions

def cmd(vk, message, args):
    peer_id = message['peer_id']
    for_all = None if message['from_id'] == message['peer_id'] else True

    assocs = functions.getData('assoc')
    if assocs is None:
        assocs = {}

    if len(args) < 2:
        functions.msg_edit(
            vk, peer_id, message['id'],
            f"{config.prefixes['invalid']} Правильное использование: /-бинд [слово]",
            for_all=for_all
        )
        return

    key = str(message['text'].split(' ', 1)[1])
    if assocs.get(key) is None:
        functions.msg_edit(
            vk, peer_id, message['id'],
            f"{config.prefixes['invalid']} Я не нашла бинда с таким названием!",
            for_all=for_all
        )
        return

    assocs.pop(key)
    functions.editData('assoc', assocs)

    functions.msg_edit(vk, peer_id, message['id'], f"{config.prefixes['success']} Успешно удалила бинд под нзванием {key}", for_all=for_all)
    return
