import time
import config
import functions


def cmd(api, message, args, owner_id, data, token):
    for_all = None if message['from_id'] == message['peer_id'] else True

    if message.get('reply_message') is not None:
        target = api.users.get(
            user_ids=message['reply_message']['from_id']
        )
    else:
        try:
            target = api.users.get(
                user_ids=functions.getUserId(args[1])
            )
        except:
            api.messages.edit(
                peer_id=message['peer_id'],
                message_id=message['id'],
                message=f"{config.prefixes['error']} Необходимо ответить на сообщение пользователя или указать на него ссылку: /бан [пользователь]"
            )
            time.sleep(3)
            api.messages.delete(
                message_ids=message['id'],
                delete_for_all=for_all
            )
            return

    info = data.get(token)

    target = target[0]
    if target['id'] in info["ban_users"]:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['invalid']} Я обнаружила, что пользователю [id{target['id']}|{target['first_name']} {target['last_name']}] уже ограничен доступ к общедоступным командам."
        )
        return

    if owner_id == target['id']:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['invalid']} Хозяин, я не могу заблокировать вас!"
        )
        return

    info["ban_users"].append(target['id'])
    edit = data.set(token, info)

    if edit:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['success']} Ок, ограничила пользователю [id{target['id']}|{target['first_name']} {target['last_name']}] доступ к общедоступным командам!"
        )
    else:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['error']} Пользователя [id{target['id']}|{target['first_name']} {target['last_name']}] У меня не получилось заблокировать. Возможно данные повреждены."
        )

    return
