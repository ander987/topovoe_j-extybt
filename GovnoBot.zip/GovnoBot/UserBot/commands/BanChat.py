import time
import config
import functions


def cmd(api, message, args, data, token):
    for_all = None if message['from_id'] == message['peer_id'] else True

    info = data.get(token)

    if message['peer_id'] in info["ban_chats"]:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['invalid']} Я уже ограничила данной беседе доступ."
        )
        time.sleep(3)
        api.messages.delete(
            message_ids=message['id'],
            delete_for_all=for_all
        )

    info["ban_chats"].append(message['peer_id'])
    edit = data.set(token, info)

    if edit:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['success']} Ок, ограничила доступ к боту данной беседе!"
        )
    else:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['error']} Мне не удалось ограничить доступ к боту данной беседе."
        )

    return