import openai
import time
import config 

def cmd(vk, message, args):
    if len(args) == 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❌Правильное использование: gpt [вопрос/задача]"
            )
    
    elif len(args) >= 2:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"⚙️Обрабатываю ваш запрос, подождите..."
            )
        
        tex = " ".join(args[1:])
        openai.api_key = config.gpt
        response = openai.Completion.create(
            model="text-davinci-003",
            prompt=tex,
            temperature=0.9,
            max_tokens=4000,
            top_p=1,
            frequency_penalty=0.0,
            presence_penalty=0.6,
            )
        otv = response['choices'][0]['text']
        
        try:
            vk.messages.edit(
                peer_id=message['peer_id'],
                message_id=message['id'],
                message=f"{otv}"
                )
        except Exception as e:
                vk.messages.send(
                    peer_id=message['peer_id'],
                    random_id=0,
                    message=f"❌Ошибка. {str(e)}"
                )