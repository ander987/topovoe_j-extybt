def cmd(vk, message, args, user_id):
    if message["peer_id"] > 2000000000:  # проверяем, что сообщение пришло из беседы
        chat_id = message["peer_id"] - 2000000000  # получаем ID беседы
        chat_info = vk.messages.getConversationsById(peer_ids=message["peer_id"], extended=1)["items"][0]["chat_settings"]  # получаем информацию о беседе
        members_count = chat_info["members_count"]  # получаем количество участников
        chat_title = chat_info["title"]  # получаем название беседы
        chat_admins = []  # создаем список администраторов
        for member in chat_info["members"]:  # проходимся по всем участникам беседы
            if "is_admin" in member:  # если у участника есть статус администратора
                if member["is_admin"]:  # и он равен True
                    chat_admins.append(member["id"])  # добавляем его ID в список администраторов
        admins_text = ", ".join([str(admin) for admin in chat_admins])  # формируем текст со списком администраторов
        vk.messages.send(
            peer_id=message["peer_id"],
            message=f"Название беседы: {chat_title}\nКоличество участников: {members_count}\nАдминистраторы: {admins_text}",
            random_id=0
        )
    else:
        vk.messages.send(
            peer_id=message["peer_id"],
            message="Команда доступна только в беседах",
            random_id=0
        )