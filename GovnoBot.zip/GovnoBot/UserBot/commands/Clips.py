from random import choice
from time import sleep
import functions
def cmd(vk, message, args, owner_id, hate, user_id):
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="❌Правильное использование команды: кфспам [ссылка на пользователя] [количество]"
            )
        return False
        
    target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
    vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message=f"✅Ок, запустила спам беседами на [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]"
        )
    for _ in range(int(args[2])):
        vk.messages.createChat(
            user_ids=user_id,
            title=choice(hate),
            )
        vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message="✅Беседа создана, жду 60 секунд."
            )
        sleep(60)
        
    vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message="✅Все беседы созданы."
            )