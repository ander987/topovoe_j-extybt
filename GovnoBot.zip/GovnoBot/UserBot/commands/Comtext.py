import os
import config
import requests
from vk_api import VkUpload
from time import sleep
import re
from random import choice


def cmd(api, message, args, uploader: VkUpload, prefix):
    for_all = None if message['from_id'] == message['peer_id'] else True
    attach = message.get('attachments')
    reply = message.get('reply_message')
        
    if len(args) <= 1:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"{config.prefixes['error']} Необходимо написать: {prefix}комтекст [кол-во] [ссылка на запись] [текст]",
            reply_to=message['id']
        )
        return

    if reply is not None:
        post_id = reply['id']
        owner_id = reply['from_id']
        text = " ".join(args[3:])
    else:
        regex = re.findall(r"wall(-?\d+)_(\d+)", args[2])
        if regex:
            owner_id, post_id = regex[0]
        else:
            api.messages.send(
                peer_id=message['peer_id'],
                random_id=0,
                message=f"{config.prefixes['error']} Пожалуйста, укажите ссылку на запись в формате: https://vk.com/wall-<owner_id>_<post_id> или ответьте на запись, которую хотите накрутить комментариями.",
                reply_to=message['id']
            )
            return

    api.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'✅Ок, запустила спам комментариями.'
            )
            
    text = " ".join(args[3:])
    
    for _ in range(int(args[1])):
        api.wall.createComment(
            owner_id=owner_id,
            post_id=post_id, 
            message=text
            )