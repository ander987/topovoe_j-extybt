import logging
import requests
import json

def cmd(vk, message, args):
    if len(args) < 2:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="Правильное использование: деанон [номер]"
            )
        return False
    
    nomer = " ".join(args[1:])
    
    url = "https://dimondevosint.p.rapidapi.com/main?phone=" + nomer
    
    head = {
        "X-RapidAPI-Host": "dimondevosint.p.rapidapi.com",
        "X-RapidAPI-Key": "___RAPIDAPI_API_KEY___"
    }
    
    response = requests.request("GET", url, headers=head)
    print(response.text)
    
    data = json.loads(response.text)

    vk.messages.edit(
        peeer_id=message['peer_id'],
        message_id=message['id'],
        message=f"├ФИО: {data['name']}\n ├Страна: {data['country']}\n ├Оператор: {data['operator']}\n ├Объявления: {data['obyavleniya']}"
        )