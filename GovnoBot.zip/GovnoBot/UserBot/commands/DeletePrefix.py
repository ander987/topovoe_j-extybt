def cmd(vk, message, data, token, profile):
    info = data.get(token)
    inf = profile.get(token)
    info["prefix"] = ""
    inf["prefix"] = ""
    data.set(token, info)
    profile.set(token, inf)

    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message=f'✅Ок, удалила префикс!'
    )

    return True