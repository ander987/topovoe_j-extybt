import config
import functions

def cmd(vk, message, args, data, token, prefix):
    peer_id = message['peer_id']
    for_all = None if message['from_id'] == message['peer_id'] else True

    audios = functions.getData('chat')
    if audios is None:
        audios = {}

    if len(args) < 2:
        functions.msg_edit(
            vk, peer_id, message['id'],
            f"{config.prefixes['invalid']} Правильное использование: {prefix}-шаб [название]",
            for_all=for_all
        )
        return

    info = data.get(token)
    key = " ".join(args[1:])
    if info["chat"].get(key) is None:
        functions.msg_edit(
            vk, peer_id, message['id'],
            f"{config.prefixes['invalid']} Я не нашла шаблон с таким названием!",
            for_all=for_all
        )
        return

    del info["chat"][key]

    data.set(token, info)

    functions.msg_edit(vk, peer_id, message['id'], f"{config.prefixes['success']} Ок, удалила шаблон {key}.", for_all=for_all)
    return
