import requests
import functions

def cmd(vk, message, args, data, hate, profiles, admins, prefix, user_id, owner_id, qiwi, ignore, admin):
    if (len(args) <= 1 or not args[1].isdigit()) and not user_id:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование "{prefix}-токен" [айди]/реплай'
        )

        return False
    
    target = vk.users.get(user_id=user_id, random_id=0)[0]
    inf = admin.get("admins")

    info = data.get()
    ids = [info[i]["owner_id"] for i in list(info)]

    if user_id not in ids:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я обнаружила, что пользователь не зарегистрирован в боте.'
        )

        return False
    
    if user_id in admins:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я не могу удалить токен моего создателя.'
        )
        return False
        
    if user_id == owner_id:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Нельзя удалить самого себя.'
        )
        return False
        

    token = [i for i in list(info) if info[i]["owner_id"] == user_id][0]

    if data.delete(token):
        hate.delete(token)
        profiles.delete(token)
        qiwi.delete(token)
        ignore.delete(token)
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f"✅Ок, удалила [id{target['id']}|{target['first_name']} {target['last_name']}] из юзеров."
        )

        return True
    
    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message='❌Не удалось удалить пользователя.'
    )
    return False