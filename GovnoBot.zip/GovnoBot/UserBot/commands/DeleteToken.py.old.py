import requests
import functions

def cmd(vk, message, args, data, hate, admins, prefix):
    if len(args) <= 1 or not args[1].isdigit():
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование "{prefix}-токен" [айди]'
        )

        return False
    
    target = vk.users.get(user_id=args[1], random_id=0)[0]

    info = data.get()
    ids = [info[i]["owner_id"] for i in list(info)]

    if int(args[1]) not in ids:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я обнаружила, что пользователь не зарегистрирован в боте.'
        )

        return False
    
    if int(args[1]) in admins:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я не могу удалить токен моего создателя.'
        )
        return False
        

    token = [i for i in list(info) if info[i]["owner_id"] == int(args[1])][0]

    if data.delete(token):
        hate.delete(token)
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f"✅Ок, заблокировала [id{target['id']}|{target['first_name']} {target['last_name']}] доступ к боту."
        )

        return True
    
    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message='❌Не удалось заблокировать пользователя.'
    )
    return False