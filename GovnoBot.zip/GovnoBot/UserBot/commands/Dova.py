def cmd(vk, message, args, dov):
    
    if len(args) <= 1:
        vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"❌Необходимо написать: {dov} [текст]"
            )
            
    elif len(args) >= 2:
        text = " ".join(args[1:])
        vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"{text}"
            )
            