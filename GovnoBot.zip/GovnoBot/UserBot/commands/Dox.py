from time import sleep
def cmd(vk, message, args, user_id):
    
    target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"✅Ок, ваш запрос принят, получаю инфформацию о пользователе: [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]"
        )
    sleep(1)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message="🔃Проверяю доступные источники информации."
        )
    sleep(0.5)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message="🔃Проверяю доступные источники информации.."
        )
    sleep(0.5)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message="🔃Проверяю доступные источники информации..."
        )
    sleep(0.5)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message="🔃Проверяю доступные источники информации."
        )
    sleep(0.5)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message="🔃Проверяю доступные источники информации.."
        )
    sleep(0.5)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message="🔃Проверяю доступные источники информации..."
        )
    sleep(0.5)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"🆘Информация про [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}] найдена в более 50 доступных источниках\nАрхив с результатом сохранён в папку «dox»\nСоздана ветка на doxbin.org"
        )
    
    