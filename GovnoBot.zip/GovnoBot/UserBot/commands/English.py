from translate import Translator
def cmd(vk, message, args, prefix):
    
    translator = Translator(from_lang="ru", to_lang="en")
    text = " ".join(args[1:])
    text2 = translator.translate(text)
    
    if len(args) < 2:
        vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message=f'❌Правильное использование команды: {prefix}инглиш "текст"' 
    )
    
    elif len(args) >= 2:
        vk.messages.edit( 
                peer_id=message["peer_id"],                 message_id=message["id"],  
                message=f'✅Результат перевода: {text2}'
        )