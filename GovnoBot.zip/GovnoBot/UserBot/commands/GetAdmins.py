def cmd(vk, message, data, admins):
    ids = data.get("admins")

    users = []
    admins_list = []

    targets = vk.users.get(user_id=ids, random_id=0) if len(ids) > 0 else []
    admins_target = vk.users.get(user_id=admins, random_id=0)

    for target in targets:
        users.append(f"[id{target['id']}|{target['first_name']} {target['last_name']}]")
    
    for admin in admins_target:
        admins_list.append(f"[id{admin['id']}|{admin['first_name']} {admin['last_name']}]")
        
    pomoch = "\n✅Помощник разраба:[https://vk.com/alix.andr|Александр Обойкин]"
    
    admins_message = "\n✅Список админов:\n" + "\n".join(users) if len(users) > 0 else ""

    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message="✅Разработчики:\n" + "\n".join(admins_list) + admins_message
    )