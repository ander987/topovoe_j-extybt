def cmd(vk, message, data, admins, token):
    
    inf = data.get(token)
    ids = inf["ignore"]
    
    if inf["ignore"] is None or len(inf["ignore"]) < 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❎В списке мутов отсутствуют пользователи!"
            )
        return
    
    inf = data.get(token)
    ids = inf["ignore"]

    users = []

    targets = vk.users.get(user_id=ids, random_id=0) if len(ids) > 0 else []

    for target in targets:
        users.append(f"[id{target['id']}|{target['first_name']} {target['last_name']}]")
    
    admins_message = "\n✅Список пользователей находящихся в муте:\n" + "\n".join(users) if len(users) > 0 else ""

    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message=f"{admins_message}"
        )