def cmd(vk, message, prefix, data, token):
    info = data.get(token)

    if info["prefix"] == "":
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌У вас не установлен префикс.'
        )
    else:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'✅Ваш префикс: "{prefix}"'
        )