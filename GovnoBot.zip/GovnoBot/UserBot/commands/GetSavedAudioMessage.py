import config
import functions


def cmd(vk, message, args, data, token, prefix):
    peer_id = message['peer_id']
    for_all = None if message['from_id'] == message['peer_id'] else True

    info = data.get(token)

    if len(args) < 2:
        functions.msg_edit(
            vk, peer_id, message['id'],
            f"{config.prefixes['invalid']} Правильное использование: {prefix}гс [название]",
            for_all=for_all
        )
        return

    key = " ".join(args[1:])
    if info["saved_audio"].get(key) is None:
        functions.msg_edit(
            vk, peer_id, message['id'],
            f"{config.prefixes['invalid']} Я не нашла голосовое с таким названием!",
            for_all=for_all
        )
        return

    reply = None
    if message.get('reply_message') is not None:
        reply = message['reply_message']['id']

    functions.msg_edit(vk, peer_id, message['id'], "✅Ок, отправляю голосовое сообщение", for_all=for_all, sleeping=0)
    functions.msg_send(vk, peer_id, attachment=info["saved_audio"].get(key), reply_to=reply)
    return
