def cmd(vk, message, data):
    info = data.get()
    ids = [info[i]["owner_id"] for i in list(info)]

    users = []

    targets = vk.users.get(user_id=ids, random_id=0)

    for target in targets:
        users.append(f"[id{target['id']}|{target['first_name']} {target['last_name']}]")

    max_length = 4096
    messages = []

    message_text = "✅Список юзеров TendoRP:\n"
    for user in users:
        if len(message_text) + len(user) >= max_length:
            messages.append(message_text)
            message_text = ""
        message_text += user + "\n"

    if message_text:
        messages.append(message_text)

    for message_text in messages:
        vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=message_text
        )

    uuser = len(users)

    vk.messages.send(
        peer_id=message['peer_id'],
        random_id=0,
        message=f"✅Количество юзеров: {uuser}"
    )