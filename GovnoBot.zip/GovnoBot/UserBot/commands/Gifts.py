def cmd(vk, message, args, user_id):
    target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
    gift = vk.gifts.get(user_id=user_id, )
    