def cmd(vk, message, data, token, time, random):
    for_all = None if message['from_id'] == message['peer_id'] else True
    info = data.get(token)
    if int(message["peer_id"]) in info["hate"]:
        info["hate"].remove(int(message["peer_id"]))
        data.set(token, info)

        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f"✅Вышла из хейт режима."
        )
        time.sleep(1)
        vk.messages.delete(
           message_ids=message['id'],
           delete_for_all=for_all
        )
    else:
        info["hate"].append(int(message["peer_id"]))
        data.set(token, info)

        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f"✅Перешла в хейт режим."
        )
        time.sleep(1)
        vk.messages.delete(
           message_ids=message['id'],
           delete_for_all=for_all
        )