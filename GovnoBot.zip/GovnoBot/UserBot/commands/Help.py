def get_commands(type_commands, prefix):
    commands = {
	    "public": [
	        {
	            "commands_alias": [f"{prefix}жма"],
	            "description": "жмых голсового сообщения",
	        },
	        {
	            "commands_alias": [f"{prefix}жмф"],
	            "description": "жмых фотографии",
	        },
	        {
	            "commands_alias": [f"{prefix}вгс"],
	            "description": "конвертация трека в голосовое сообщение",
	        },
	        {
	            "commands_alias": [f"{prefix}нег"],
	            "description": "перевести фотографию в негатив",
	        },
	        {
	            "commands_alias": [f"{prefix}дем"],
	            "description": "создать демотиватор",
	        },
	        {
	            "commands_alias": [f"{prefix}тч"],
	            "description": "проверить пользователя на тестера ВК",
	        },
	        {
	            "commands_alias": [f"{prefix}стики"],
	            "description": "узнать количество стикеров пользователя",
	        },
	        {
	            "commands_alias": [f"{prefix}инфо"],
	            "description": "узнать ID пользователя",
	        },
	        {
	            "commands_alias": [f"{prefix}рег"],
	            "description": "Получить ссылку для регистрации в боте",
	        },
	        {
	            "commands_alias": [f"{prefix}инфа"],
	            "description": "вероятность случайного события",
	        },
	    ],
	    "private": [
	        {
	            "commands_alias": [f"{prefix}бан"],
	            "description": "заблокировать доступ к боту пользователю (бот не будет реагировать на него)",
	        },
	        {
	            "commands_alias": [f"{prefix}бан_чат"],
	            "description": "заблокировать чат (бот не будет в нем работать)",
	        },
	        {
	            "commands_alias": [f"{prefix}префикс"],
	            "description": "сменить префикс",
	        },
	        {
	            "commands_alias": [f"{prefix}накрутка"],
	            "description": "накрутка фото в альбом",
	        },
	        {
	            "commands_alias": [f"{prefix}игра"],
	            "description": "игра орёл или решка",
	        },
	        {
	            "commands_alias": ["мпреф"],
	            "description": "посмотреть установленный на текущий момент префикс",
	        },
	        {
	            "commands_alias": [f"{prefix}хейт"],
	            "description": "хейт режим(вкл/выкл)",
	        },
	        {
	            "commands_alias": [f"{prefix}-спам"],
	            "description": "остановить спам",
	        },
	        {
	            "commands_alias": [f"{prefix}+шаб"],
	            "description": "добавить шаблон",
	        },
	        {
	            "commands_alias": [f"{prefix}шаб"],
	            "description": "отправить шаблон",
	        },
	        {
	            "commands_alias": [f"{prefix}-шаб"],
	            "description": "удалить шаблон",
	        },
	        {
	            "commands_alias": [f"{prefix}шабы"],
	            "description": "список шаблонов",
	        },
	        {
	            "commands_alias": [f"{prefix}гтян"],
	            "description": "генератор тянок",
	        },
	        {
	            "commands_alias": [f"{prefix}тайм"],
	            "description": "спам с вложениями",
	        },
	        {
	            "commands_alias": [f"{prefix}-тайм"],
	            "description": "убрать спам с вложениями",
	        },
	        {
	            "commands_alias": [f"{prefix}рп"],
	            "description": "рп действия",
	        },
	        {
	            "commands_alias": [f"{prefix}реши"],
	            "description": "решение примеров",
	        },
	        {
	            "commands_alias": [f"{prefix}проф"],
	            "description": "информация о профиле вк",
	        }, 
	        {
	            "commands_alias": [f"{prefix}спам оск"],
	            "description": "Спам оскорблениями",
	        }, 
	        {
	            "commands_alias": [f"{prefix}префикс дефолт"],
	            "description": "установить дефолтный префикс",
	        }, 
	        {
	            "commands_alias": [f"{prefix}-префикс"],
	            "description": "удалить префикс",
	        }, 
	        {
	            "commands_alias": [f"{prefix}gpt"],
	            "description": "ChatGPT",
	        }, 
	        {
	            "commands_alias": [f"{prefix}профиль"],
	            "description": "посмотреть свой профиль в TendoRP",
	        }, 
	        {
	            "commands_alias": [f"{prefix}пинг"],
	            "description": "замерить пинг",
			},
			{
				"commands_alias": [f"{prefix}киви"],
				"description": "управление киви кошельком",
			},
			{
				"commands_alias": [f"{prefix}чатспам"],
				"description": "спам изменением названия чата",
			},
			{
				"commands_alias": [f"{prefix}+чат"],
				"description": "создать беседу ВКонтакте",
			},
			{
				"commands_alias": [f"{prefix}валлспам"],
				"description": "спам записями на стене пользователя",
			},
			{
				"commands_alias": [f"{prefix}мут/анмут"],
				"description": "сообщения человека будут удалятся у вас",
			},
			{
				"commands_alias": [f"{prefix}валлтекст"],
				"description": "спам записями на стене пользователя со своим текстом",
			},
			{
				"commands_alias": [f"{prefix}влс"],
				"description": "отправить сообщение в лс пользователю",
	        }, 
	        {
	            "commands_alias": [f"{prefix}+статус"],
	            "description": "установить статус",
	        }, 
	        {
	            "commands_alias": [f"{prefix}+/-др"],
	            "description": "добавить/удалить пользователя из друзей",
	        }, 
	        {
	            "commands_alias": [f"{prefix}+/-чс"],
	            "description": "добавить/удалить пользователя из чёрного списка",
	        }, 
	        {
	            "commands_alias": [f"{prefix}переведи"],
	            "description": "перевести текст с английского на русский язык",
	        }, 
	        {
	            "commands_alias": [f"{prefix}инглиш"],
	            "description": "перевести текст с русского на английский язык",
	        }, 
	        {
	            "commands_alias": [f"{prefix}вики"],
	            "description": "запрос в Википедию",
	        },
	        {
	            "commands_alias": [f"{prefix}кгс"],
	            "description": "скопировать голосовое сообщение (бот отправит скопированное вами голосовое)",
	        }, 
	        {
	            "commands_alias": [f"{prefix}кик"],
	            "description": "исключить пользователя из чата",
	        },
	        {
	            "commands_alias": [f"{prefix}инвайт"],
	            "description": "добавить пользователя в чат",
	        },
	        {
	            "commands_alias": [f"{prefix}погода"],
	            "description": "узнать погоду в выбранном городе",
	        },
	        {
	            "commands_alias": [f"{prefix}дел"],
	            "description": "удалить выбраное кол-во сообщений",
	        },
	        {
	            "commands_alias": [f"{prefix}-бот"],
	            "description": "отключить бота для общедоступного использования (бот не будет реагировать на остальных)",
	        },
	        {
	            "commands_alias": [f"{prefix}изч"],
	            "description": "отправить исчезающие сообщение",
	        },
	        {
	            "commands_alias": [f"{prefix}спам упом"],
	            "description": "спам упоминанием",
	        },
	        {
	            "commands_alias": [f"{prefix}делток"],
	            "description": "удалить свой токен из бота",
	        },
	        {
	            "commands_alias": [f"{prefix}комспам"],
	            "description": "спам в комментариях оскорблениями",
	        },
	        {
	            "commands_alias": [f"{prefix}комтекст"],
	            "description": "спам в комментариях своим текстом",
	        },
	        {
	            "commands_alias": [f"{prefix}г"],
	            "description": "посмотреть группы созданные пользователем",
	        },
	        {
	            "commands_alias": [f"{prefix}озвучь"],
	            "description": "озвучить текст в голосовое сообщение",
			},
			{
				"commands_alias": [f"{prefix}спкнч"],
				"description": "анимированное пожелание спокойной ночи",
			},
			{
				"commands_alias": [f"{prefix}love"],
				"description": "анимированная валентинка",
	        },
	        {
	            "commands_alias": [f"{prefix}спам"],
	            "description": "спам выбраным текстом",
	        },
	        {
	            "commands_alias": [f"{prefix}+гс"],
	            "description": "сохранить голосовое",
	        },
	        {
	            "commands_alias": [f"{prefix}гс"],
	            "description": "отправить сохранённое голосовое",
	        },
	        {
	            "commands_alias": [f"{prefix}-гс"],
	            "description": "удалить сохранённое голосовое",
	        },
	        {
	            "commands_alias": [f"{prefix}гсы"],
	            "description": "список сохранённых голосовых",
	        },
	        {
	            "commands_alias": [f"{prefix}разбан"],
	            "description": "разблокировать пользователю доступ к боту",
	        }, 
	        {
	            "commands_alias": [f"{prefix}админы"],
	            "description": "список администрации бота",
	        },
	        {
	            "commands_alias": [f"{prefix}разбан_чат"],
	            "description": "разблокировать чату доступ к боту",
	
	        },
	        {
	            "commands_alias": ["+с, -с"],
	            "description": "открыть(закрыть) пользователю доступ к сохрам",
	        },
	        {
	            "commands_alias": ["+м, -м"],
	            "description": "открыть(закрыть) пользователю доступ к аудиозаписям",
	        },
	    ]
	}
    out = ""
    for command in commands[type_commands]:
        alias_transform = ", ".join(command['commands_alias'])
        description = command['description']
        out += f"{alias_transform} -- {description}\n"
    return out


def cmd(api, message, owner_id, prefix):
    universal_message = "\n🤡Разработчик: [https://vk.com/tendo|Tendo Diverso]\n❤Помощник разраба: [https://vk.com/alix.andr|Сашечка]"
    github = "\n❔  [vk.com/@lptendorp-komandy-tendorp|Полный список команд]"
    main_message = f"✅Общедоступные команды TendoRP:\n{get_commands('public', prefix)}"

    if message['from_id'] == owner_id:
        main_message += f"\n❌Команды юзеров бота:\n{get_commands('private', prefix)}"
        universal_message += github

    main_message += universal_message

    api.messages.send(
        peer_id=message['peer_id'],
        random_id=0,
        message=main_message,
        reply_to=message['id']
    )