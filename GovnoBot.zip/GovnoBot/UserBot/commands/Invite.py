def cmd(vk, message, args, prefix, user_id):
    
    if len(args) <= 2:
        vk.messages.addChatUser(
            chat_id=message['peer_id']-2000000000,
            user_id=user_id
        )
        
        target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
        
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"✅Ок, добавила в беседу [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]"
            )