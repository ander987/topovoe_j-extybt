def cmd(vk, message, args, prefix, user_id, owner_id):
    
    if len(args) >= 3:
        vk.messages.removeChatUser(
            chat_id=message['peer_id']-2000000000,
            user_id=user_id
        )
        
        target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
        text = " ".join(args[1:])
        
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"✅Ок, удалила из беседы [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}] по причине: {text}"
            )
            
    if len(args) <= 2:
        vk.messages.removeChatUser(
            chat_id=message['peer_id']-2000000000,
            user_id=user_id
        )
        
        target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
        
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"✅Ок, удалила из беседы [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]"
            )
            
    elif user_id == owner_id:
        vk.message.edit(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"❌Вы не можете исключить сами себя из чата."
            )