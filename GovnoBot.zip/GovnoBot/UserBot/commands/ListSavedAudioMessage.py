import config
import functions


def split_list(lst, max_len):
    """
    Разделяет список на части, каждая из которых не превышает заданную максимальную длину
    """
    result = []
    sub_list = []
    current_len = 0

    for item in lst:
        item_len = len(str(item))
        if current_len + item_len > max_len:
            result.append(sub_list)
            sub_list = []
            current_len = 0
        sub_list.append(item)
        current_len += item_len
    if sub_list:
        result.append(sub_list)

    return result


def cmd(vk, message, data, token):
    peer_id = message['peer_id']
    for_all = None if message['from_id'] == message['peer_id'] else True

    info = data.get(token)
    if info["saved_audio"] is None or len(info["saved_audio"]) < 1:
        functions.msg_edit(
            vk, peer_id, message['id'],
            f"{config.prefixes['invalid']} У Вас нет сохранённых голосовых сообщений.",
            for_all=for_all
        )
        return

    names = list(info["saved_audio"])
    num = len(names)
    
    # Разбиваем список на части
    splitted_names = split_list(names, 4000)  # Максимальная длина сообщения - 4096 символов
    
    # Отправляем каждую часть в отдельном сообщении
    for i, names_part in enumerate(splitted_names):
        text = f"📖 Ваши сохранённые голосовые сообщения, часть {i+1} из {len(splitted_names)}: {', '.join(names_part)}\nКоличество: {num}"
        functions.msg_edit(vk, peer_id, message['id'], text, sleeping=None)

