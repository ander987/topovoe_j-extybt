import config
import functions


def split_list(lst, max_len):
    
    result = []
    sub_list = []
    current_len = 0

    for item in lst:
        item_len = len(str(item))
        if current_len + item_len > max_len:
            result.append(sub_list)
            sub_list = []
            current_len = 0
        sub_list.append(item)
        current_len += item_len
    if sub_list:
        result.append(sub_list)

    return result


def cmd(vk, message, data, token):
    peer_id = message['peer_id']
    for_all = None if message['from_id'] == message['peer_id'] else True

    info = data.get(token)
    if info["chat"] is None or len(info["chat"]) < 1:
        functions.msg_edit(
            vk, peer_id, message['id'],
            f"{config.prefixes['invalid']} У Вас нет сохранённых шаблонов",
            for_all=for_all
        )
        return

    names = list(info["chat"])
    num = len(names)
    
    splitted_names = split_list(names, 4000)
    
    for i, names_part in enumerate(splitted_names):
        text = f"📖 Ваши сохранённые шаблоны, часть {i+1} из {len(splitted_names)}: {', '.join(names_part)}\nКоличество: {num}"
        functions.msg_edit(vk, peer_id, message['id'], text, sleeping=None)