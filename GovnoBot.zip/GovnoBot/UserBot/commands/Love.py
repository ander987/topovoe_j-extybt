from time import sleep
def cmd(vk, message, args, time):
    
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'I'
            )
    time.sleep(0.6)
    
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'Love'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'You'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️🧡'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️🧡💛'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️🧡💛💚'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️🧡💛💚💙'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️🧡💛💚💙💜'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️🧡💛💚💙'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️🧡💛💚'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️🧡💛'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️🧡'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️Ты'
            )
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️Ты солнце:)'
            )
    time.sleep(0.6)