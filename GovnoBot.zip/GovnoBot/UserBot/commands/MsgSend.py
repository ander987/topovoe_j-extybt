def cmd(vk, message, args, user_id, owner_id):
    
    if len(args) == 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"Правильное использование: влс [пользователь] [текст]"
            )
        return False
            
    if user_id == owner_id:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'] ,
            message=f"Написать кому?😐"
            )
        return False
    
    if len(args) >= 2:
        target = vk.users.get(user_id=user_id, name_case="dat", random_id=0)
        text = " ".join(args[1:])
        
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, отправила [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}] сообщение «{text}»"
            )
        
        vk.messages.send(
            peer_id=user_id,
            message=f"{text}",
            random_id=0
            )
        return True