import os
import config
import requests
from vk_api import VkUpload

def cmd(api, message, owner_id, uploader: VkUpload):
    for_all = None if message['from_id'] == message['peer_id'] else True
    attach = message.get('attachments')
    reply = message.get('reply_message')
        
    if len(attach) == 0 and reply is None:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"{config.prefixes['error']} Необходимо прикрепить аудиозапись или ответить на сообщение с аудиозаписью.",
            reply_to=message['id']
        )
        return

    try:
        if reply is not None:
            _type = reply['attachments'][0]['type']
            if _type == 'audio':
                audio = reply['attachments'][0]['audio']
            else:
                raise Exception()
        else:
            audio = attach[0]['audio']
            audio_id = audio['id']
            audio_info = vk.audio.getById(audios=audio_id)
            audio_url = audio_info[0]['url']
    except:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"{config.prefixes['error']} Необходимо прикрепить аудиозапись или ответить на сообщение с аудиозаписью.",
            reply_to=message['id']
        )
        return

    if owner_id == message['from_id']:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅ Начала конвертировать..."
        )
        api.messages.delete(
            message_ids=message['id'],
            delete_for_all=for_all
        )
    else:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"✅ Начала конвертировать...",
            reply_to=message['id']
        )

    filename = "files/" + os.path.basename(audio['url'])
    if len(filename.split('.')) < 2:
        filename += ".mp3"

    r = requests.get(audio['url'])
    with open(filename, 'wb') as f:
        f.write(r.content)

    if os.path.isfile('files/new_audio.wav'):
        os.remove('files/new_audio.wav')
    os.system(f"ffmpeg -i {filename} -acodec pcm_s32le -ar 44100 -ac 1 -b:a 256k files/new_audio.wav")

    uploaded = uploader.audio_message('files/new_audio.wav', message['peer_id'])['audio_message']
    attach = f"audio_message{uploaded['owner_id']}_{uploaded['id']}"

    os.remove(filename)
    os.remove("files/new_audio.wav")

    api.messages.send(
        peer_id=message['peer_id'],
        random_id=0,
        attachment=attach,
    )
    return