def cmd(vk, message, data_admins, profiles, admins, user_id, prefix, data, token):
    if user_id != None:
        if message["from_id"] not in (data_admins.get("admins") + admins) and user_id != message["from_id"]:
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='❌Профили других пользователей могу смотреть только админы.'
            )

            return False

    else:
        user_id = message["from_id"]
    
    info = profiles.get()
    
    if user_id not in [info[i]["owner_id"] for i in info]:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Пользователь не является юзером TendoRP.'
        )

        return False
    
    user = [info[i] for i in info if user_id == info[i]["owner_id"]][0]
    
    target = vk.users.get(user_id=user_id, random_id=0, name_case="gen")[0]
    
    i = info[i]
    
    targ = requests.post(f"https://api.vk.com/method/users.get?name_case=dat&access_token={i}&v=5.131").json()
    
    if not targ.get("response"):
        text = f'''✅Профиль [id{target['id']}|{target['first_name']} {target['last_name']}]
дата регистрации в боте: \n{user["registration"]}
Токен: Не валид❌
{user["user_type"]}'''

    else:
        text = f'''✅Профиль [id{target['id']}|{target['first_name']} {target['last_name']}]
дата регистрации в боте: \n{user["registration"]}
Токен: Валид✅
{user["user_type"]}'''
    
    if user["active"] != 1:
        text += f'\nЗарегистрирован до: {user["active"]}'

    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message=text
    )