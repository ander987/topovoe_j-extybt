def cmd(vk, message, args, prefix):
    vk.messages.send(
        peer_id=message['peer_id'],
        reply_to=message['id'],
        random_id=0,
        message=f"├Помощь по использованию TendoRP\n├Разработчик - [https://vk.com/tendo|Tendo Diverso]\n├Администратор - [https://vk.com/alix.andr|Сашенька]\n├Сообщество - [https://vk.com/lptendorp|Тык]\n├Список команд - [https://m.vk.com/@lptendorp-komandy-tendorp|Тык]\n└Наша беседа - [https://vk.me/join/AJQ1dx1oQibW1vtsrAqED5Fi|Тык]"
        )