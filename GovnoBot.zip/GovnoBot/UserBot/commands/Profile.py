import time 
import datetime 

def cmd(vk, message, data_admins, profiles, admins, user_id, prefix, data, token): 
    if user_id != None: 
        if message["from_id"] not in (data_admins.get("admins") + admins) and user_id != message["from_id"]: 
            vk.messages.edit( 
                peer_id=message["peer_id"],  
                message_id=message["id"],  
                message='❌Профили других пользователей могу смотреть только админы.' 
            ) 
 
            return False 
 
    else: 
        user_id = message["from_id"] 
     
    info = profiles.get() 
     
    if user_id not in [info[i]["owner_id"] for i in info]: 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message='❌Пользователь не является юзером TendoRP.' 
        ) 
 
        return False 
     
    user = [info[i] for i in info if user_id == info[i]["owner_id"]][0] 
     
    target = vk.users.get(user_id=user_id, random_id=0, name_case="gen")[0] 
    status = vk.status.get(user_id=user_id) 
    delta = datetime.timedelta(hours=3, minutes=0)  
    t = (datetime.datetime.now(datetime.timezone.utc) + delta)  
    nowtime = t.strftime("%H:%M") 
    nowdate = t.strftime("%d.%m.%Y") 

    # Проверяем наличие доступа к списку друзей и выводим количество онлайн
    try:
        only = vk.friends.getOnline(user_id=user_id) 
        online = len(only) 
    except Exception as e:
        # Если ошибка, то количество онлайн не выводим
        online = "недоступно"

    if user["status"] == True: 
        text = f'''✅Профиль [id{target['id']}|{target['first_name']} {target['last_name']}]\n🕛дата регистрации в боте: \n{user["registration"]}\n⚠️Токен: {user["token"]}\n💜Должность: {user["user_type"]}\n🔥Спам: Запущен✅\n🧛Баланс автокапчи: Безлимит\n⌛Время: {nowtime}\n📅Дата: {nowdate}\n🖤Друзей онлайн: {online}\n❎Префикс: «{user["prefix"]}»''' 
     
    if user["status"] == False: 
        text = f'''✅Профиль [id{target['id']}|{target['first_name']} {target['last_name']}]\n🕛дата регистрации в боте: \n{user["registration"]}\n⚠️Токен: {user["token"]}\n💜Должность: {user["user_type"]}\n🔥Спам: Не запущен❌\n🧛Баланс автокапчи: Безлимит\n⌛Время: {nowtime}\n📅Дата: {nowdate}\n🖤Друзей онлайн: {online}\n❎Префикс: «{user["prefix"]}»''' 
     
    if user["active"] != 1: 
        text += f'\nЗарегистрирован до: {user["active"]}' 
 
    vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message=text 
    )