from SimpleQIWI import *
from db import vkdb
def cmd(vk, message, args, data, token, time):
    
    if len(args) <= 1:
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❌Правильное использование команды: киви [баланс, перевод, профиль, номер, токен, сумма, помощь, делит, проверка, ток]'
            )
    
    if args[1] == "баланс":
        text = " ".join(args[2:])
        inf = data.get(token)
        tok = inf["tok"]
        phone = inf["num"]
        summa = inf["sum"]
        api = QApi(token=tok, phone=phone)
        balance = (api.balance)
        
        text=f'✅Баланс Qiwi кошелька: {balance}'
        if tok == "Не указан":
            text="❌Баланс недоступен.\nПривяжите токен Qiwi."
        return
    
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'✅Баланс Qiwi кошелька: {balance}'
            )
            
    if args[1] == "профиль":
        inf = data.get(token)
        tok = inf["tok"]
        phone = inf["num"]
        summa = inf["sum"]
        pay = inf["pay"]
        
        if inf["tok"] != "Не указан":
            vk.messages.edit(
                peer_id=message['peer_id'],
                message_id=message['id'],
                message=f"🥝Ваш профиль Qiwi:\nНомер телефона: {phone}\nСумма для переводов: {summa}\nТокен Qiwi: привязан✅"
                )
                
        if inf["tok"] == "Не указан":
            vk.messages.edit(
                peer_id=message['peer_id'],
                message_id=message['id'],
                message=f"🥝Ваш профиль Qiwi:\nНомер телефона: {phone}\nСумма для переводов: {summa}\nТокен Qiwi: Не привязан❌"
                )
            
    if args[1] == "перевод":
        inf = data.get(token)
        tok = inf["tok"]
        phone = inf["num"]
        pri = inf["sum"]
        number = " ".join(args[2:])
        qiwi = QApi(token=tok, phone=phone)
        
        qiwi.pay(account=number, amount=pri)
        
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, перевела {pri}р на Qiwi {number}"
            )
            
    if args[1] == "токен":
        inf = data.get(token)
        tok = inf["tok"]
        phone = inf["num"]
        summa = inf["sum"]
        text = " ".join(args[2:])
        inf["tok"] = text + ""
        data.set(token, inf)
        
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, сменила токен"
            )
            
    if args[1] == "сумма":
        inf = data.get(token)
        tok = inf["tok"]
        phone = inf["num"]
        summa = inf["sum"]
        text = " ".join(args[2:])
        inf["sum"] = text + ""
        data.set(token, inf)
        
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, сменила сумму на {text}"
            )
            
    if args[1] == "номер":
        inf = data.get(token)
        tok = inf["tok"]
        phone = inf["num"]
        summa = inf["sum"]
        text = " ".join(args[2:])
        inf["num"] = text + ""
        data.set(token, inf)
        
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, сменила номер на {text}"
            )
            
    if args[1] == "помощь":
        text = f"✅Помощь по использованию команды: киви\nбаланс - баланс киви кошелька\nпрофиль - данные киви записанные в боте\nтокен - сменить токен\nномер - сменить номер\nсумма - сменить сумму перевода\nперевод - перевод денег\nделит - удалить данные из бота\nпроверка - проверка входящего платежа\nТок - узнать свой токен киви"
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=text
            )
            
    if args[1] == "делит":
        inf = data.get(token)
        inf["tok"] = "Не указан"
        inf["num"] = "Не указан"
        inf["sum"] = "Не указана"
        data.set(token, inf)
        
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"✅Ок, удалила данные Qiwi"
            )
            
    if args[1] == "ток":
        inf = data.get(token)
        tok = inf["tok"]
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"🥝Ваш токен Qiwi: {tok}"
            )
            
    if args[1] == "проверка":
        inf = data.get(token)
        tok = inf["tok"]
        phone = inf["num"]
        price = " ".join(args[2:])
        api = QApi(token=tok, phone=phone)
        comment = api.bill(price)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"⏳Приём платежа на сумму: {price}р\nКомментарий для перевода: {comment}\nРеквезиты: {phone}\nПроверка платежа запущена!"
            )
            
        api.start()
        
        while True:
            if api.check(comment):
                vk.message.send(
                    peer_id=message['peer_id'],
                    random_id=0,
                    message="✅Платёж прошёл успешно!"
                    )
                break
            time.sleep(1)
        api.stop()