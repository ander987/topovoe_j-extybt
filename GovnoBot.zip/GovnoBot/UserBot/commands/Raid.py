from random import choice
from time import sleep
def cmd(vk, message, args, hate):
    
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❌Правильное использование команды: рейд [кол-во]"
            )
            
    elif len(args) >= 2:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"🤡@all, кажется вас сейчас зарейдят:)"
            )
            
        for _ in range(int(args[1])):
            vk.messages.editChat(
                chat_id=message['peer_id']-2000000000,
                title=choice(hate)
                )
                
            vk.messages.send(
                peer_id=message["peer_id"],                 message=f"@all" + "\n" + choice(hate),
                random_id=0
                )
        