def cmd(vk, message, args, user_id):
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="❌Правильное использование команды: жалоба [текст]"
            )
        return False

    text = " ".join(args[1:])

    vk.users.report(
        user_id=user_id,
        type=spam,
        comment=text
        )

    target = vk.users.get(user_id=user_id,      name_case="acc", random_id=0)
    vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message=f"✅Ок, отправила жалобу на пользователя [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]"
            )