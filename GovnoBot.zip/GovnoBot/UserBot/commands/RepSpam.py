from time import sleep
from random import choice
from vk_captchasolver import solve

def captcha_handler(captcha):
   sid = captcha.sid
   kod = captcha.get_url().split('&')
   result = solve(image=kod[0], sid=int(sid), s=1)
   return captcha.try_again(result)

def cmd(vk, message, args, data, token, hate, prefix, time, user_id, qiwi):
    for_all = None if message['from_id'] == message['peer_id'] else True
    target = vk.users.get(user_id=user_id, name_case="nom", random_id=0)
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование "{prefix}спам упом" [пользователь]'
        )

        return False

    info = data.get(token)
    info["spam"] = True
    data.set(token, info)
    inf = qiwi.get(token)
    inf["status"] = True
    qiwi.set(token, inf)

    c = True
    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message='✅Ок, запустила спам.'
    )
    vk.messages.delete(
       message_ids=message['id'],
       delete_for_all=for_all
        )
    while c:
        try:
            if data.get(token)["spam"]:
                tex = choice(hate)
                vk.messages.send(
                    peer_id=message["peer_id"], 
                    message=f'[id{user_id}|{tex}]',
                    random_id=0
                )
            else:
                c = False

        except:
            sleep(0.5)
            
    info = data.get(token)
    info["spam"] = True
    data.set(token, info)
    inf = qiwi.get(token)
    inf["status"] = True
    qiwi.set(token, inf)
    
    return True