def cmd(vk, message, args, user_id):
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"Правильное использование: репост [ссылка на запись]"
            )
        return
    
    url = research("https://vk.com_wal{user_id}_{wal_id}")
    
    