def cmd(vk, message, args, user_id, owner_id):
    text = join(args[1:])
    targets = vk.users.get(user_id=user_id, random_id=0)
    target = vk.users.get(user_id=owner_id, random_id=0)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"✅[id{target['id']}|{target['first_name']} {target['last_name']}] {text} [id{targets['id']}|{targets['first_name']} {targets['last_name']}]"
        )