def cmd(vk, message, args, user_id, owner_id):
    
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❌Правильное использование команды: рп [действие]"
            )
    
    elif len(args) >= 2:
        target = vk.users.get(user_id=owner_id, name_case="nom", random_id=0)
        targt = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
        text = " ".join(args[1:])
        
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅[id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}] {text} [id{targt[0]['id']}|{targt[0]['first_name']} {targt[0]['last_name']}]"
            )