def cmd(vk, message, args, gTTS, requests, prefix, time):
    for_all = None if message['from_id'] == message['peer_id'] else True
    if len(args) < 3 or (args[1].lower() not in ["1", "2", "3", "ru", "en", "de"]):
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование команды "{prefix}озвучь [код страны(1/2/3)] [текст]"'
        )

        return False
    
    if args[1] == "1":
        lang = "ru"
    elif args[1] == "2":
        lang = "en"
    elif args[1] == "3":
        lang = "de"
    else:
        lang = args[1]
        
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Начала озвучивать..."
            )
        time.sleep(1)
    vk.messages.delete(
       message_ids=message['id'],
       delete_for_all=for_all
        )

    tts = gTTS(text=" ".join(args[2:]), lang=lang)
    tts.save("Say.ogg")
    audio = open('Say.ogg','rb')

    a=vk.docs.getMessagesUploadServer(type='audio_message')

    b = requests.post(a['upload_url'], files={'file':audio}).json()

    c = vk.docs.save(file=b['file'])

    docum = 'doc%s_%s_%s'%(c['audio_message']['owner_id'],c['audio_message']['id'],c['audio_message']['access_key'])
    
    vk.messages.send(peer_id=message["peer_id"],random_id = 0,attachment=docum)