import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from vk_api.utils import get_random_id
def cmd(vk, message, args):
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="❌Правильное использование: sendmsg [текст]"
            )
        return False
        
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message="✅Начинаю рассылку."
            )
        
    GROUP_ID = 219384588
    TOKEN = "vk1.a.3vQKW_wF1v7dWn4khyrVJrXmcveYb9abiK7gZ6W6ZU02O-IP2nm3Vjtz8K3B7EZRwezqc-_3u-9OE7Scwep7LidPtGRBDMBFi514BEYhVRnfmfjtIJTcFZDcMhB0BojrcZow-QkwQAZHQ99PHoHYTEWdZluW6BLnq-6YCIhsP-6VTSdjUh2fpqdEK8gtCdlpzwstWkFnWX-3pggv7hvOmA"
    
    text = " ".join(args[1:])

    vk_session = vk_api.VkApi(token=TOKEN)
    longpoll = VkBotLongPoll(vk_session, GROUP_ID)
    api = vk_session.get_api()
    def send_message(peer_id, message):
        try:
            api.messages.send(
                peer_id=441846559,
                random_id=0,
                message=message
                )
        except Exception as e:
            print(f"Ошибка при отправке сообщения: {str(e)}")
    
        subscribers = api.groups.getMembers(group_id='219384588', v=5.131)['items']
        for subscriber in subscribers:
            try:
                api.messages.send(user_id=subscriber, message=f'{text}', random_id=0)
                send_message(441846559, f'✅Сообщение отправлено пользователю {subscriber}')
            except vk_api.exceptions.ApiError as e:
                send_message(441846559, f'❌Ошибка отправки сообщения пользователю {subscriber}: {e}')