def cmd(vk, message, args, data, token):
    if len(args) < 2:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="❌Правильное использование команды: шаб [название]"
        )
        return False
    
    info = data.get(token)
    key = " ".join(args[1:])
    template = info["chat"].get(key)
    
    if not template:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="❌Шаблон не найден"
        )
        return False
    
    text = template.get('text')
    media = template.get('media', [])
    
    attachment_string = ','.join(media)
    
    if "audio_message" in attachment_string:
        vk.messages.send(
            peer_id=message['peer_id'],
            message=text,
            attachment=attachment_string
        )
        vk.messages.delete(
            message_ids=message['id'],
            delete_for_all=True
        )
    else:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=text,
            attachment=attachment_string
        )