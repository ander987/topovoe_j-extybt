def cmd(vk, message, args):
    dialogs = vk.messages.getDialogs(unread=1)['items']
    for dialog in dialogs:
        peer_id = dialog['message']['user_id'] or dialog['message']['chat_id']
        last_message_id = dialog['message']['id']
        messages = vk.messages.getHistory(peer_id=peer_id, start_message_id=last_message_id)['items']
        for message in messages:
            if message['read_state'] == 0:
                print(message['text'])
read_unread_messages()