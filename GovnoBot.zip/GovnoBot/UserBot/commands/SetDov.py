def cmd(vk, message, args, dov, token, prefix):
    if len(args) < 2:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование команды "{prefix}дов [текст]"'
        )

        return False

    text = " ".join(args[1:])
    info = dov.get(token)
    if text == "дефолт":
        if info["prefix"] == "Не указан":
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='❌Я обнаружила, что у вас и так дефолтный дов префикс.'
            )
            return False
        
        else:
            info["prefix"] = "Не указан"
            data.set(token, info)
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='✅Ок, установила дефолтный дов префикс "Не указан"'
            )
            return True

    else:
        info["prefix"] = text + " "
        dov.set(token, info)
        
    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message=f'✅Ок, сменила дов префикс на «{text}»!'
    )

    return True