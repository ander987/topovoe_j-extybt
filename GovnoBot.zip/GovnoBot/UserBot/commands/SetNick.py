def cmd(vk, message, args, data, token):
    info = data.get(token)
    nick = info["nick"]
    text = " ".join(args[1:])
    info["nick"] = text + ""
    data.set(token, info)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"✅Ок, сменила ник на {text}"
        )
    