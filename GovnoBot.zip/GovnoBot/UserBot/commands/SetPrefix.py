def cmd(vk, message, args, data, token, prefix, profile):
    if len(args) < 2:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование команды "{prefix}префикс [текст]"'
        )

        return False

    text = " ".join(args[1:])
    info = data.get(token)
    inf = profile.get(token)
    if text == "дефолт":
        if info["prefix"] == "/":
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='❌Я обнаружила, что у вас и так дефолтный префикс.'
            )
            return False
        
        else:
            info["prefix"] = "/"
            data.set(token, info)
            inf["prefix"] = "/"
            profile.set(token, inf)
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='✅Ок, установила дефолтный префикс "/"'
            )
            return True

    else:
        info["prefix"] = text + " "
        data.set(token, info)
        inf["prefix"] = text + " "
        profile.set(token, inf)

    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message=f'✅Ок, сменила префикс на "{text}"!'
    )

    return True