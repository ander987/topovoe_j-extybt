def cmd(vk, message, args, data, token):
    info = data.get(token)
    
    reply = message.get('reply_message')
    text = reply.get('text')
    name = " ".join(args[1:])
    
    attachments = reply.get('attachments', [])
    media = []
    
    for attachment in attachments:
        attachment_type = attachment['type']
        attachment_data = attachment[attachment_type]
        
        if attachment_type == 'photo':
            photo_sizes = attachment_data['sizes']
            max_size = max(photo_sizes, key=lambda size: size['width'])
            photo_id = max_size.get('id')
            if photo_id:
                media.append(f"photo{attachment_data['owner_id']}_{photo_id}")
                # Save the photo by downloading or storing its URL
                photo_url = max_size.get('url')
                # Your code to save the photo goes here
                
        elif attachment_type == 'audio_message':
            audio_id = attachment_data.get('id')
            if audio_id:
                media.append(f"doc{attachment_data['owner_id']}_{audio_id}")
        elif attachment_type == 'video':
            video_id = attachment_data.get('id')
            if video_id:
                media.append(f"video{attachment_data['owner_id']}_{video_id}")
    
    info["chat"][name] = {
        'text': text,
        'media': media
    }
    
    data.set(token, info)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"✅Ок, добавила шаблон под названием «{name}»"
    )
