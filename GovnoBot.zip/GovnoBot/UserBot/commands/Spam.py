from time import sleep

def cmd(vk, message, args, data, token, prefix, time, qiwi):
    for_all = None if message['from_id'] == message['peer_id'] else True
    if len(args) < 3:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование "{prefix}спам" [кол_во(1-100)] [интервал(0-60)] [текст]'
        )

        return False
    
    
    text = " ".join(args[3:])

    info = data.get(token)
    info["spam"] = True
    data.set(token, info)
    inf = qiwi.get(token)
    inf["status"] = True
    qiwi.set(token, inf)
    
    c = True
    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message='✅Ок, запустила спам.'
    )
    time.sleep(1)
    vk.messages.delete(
       message_ids=message['id'],
       delete_for_all=for_all
        )

    i = 0
    while i < int(args[1]):
        try:
            if data.get(token)["spam"]:
                vk.messages.send(
                    peer_id=message["peer_id"],  
                    message=text,
                    random_id=0
                )
                sleep(int(args[2]))
                i += 1
            else:
                i = int(args[1])

        except:
            sleep(1)
            
    info = data.get(token)
    info["spam"] = True
    data.set(token, info)
    inf = qiwi.get(token)
    inf["status"] = True
    qiwi.set(token, inf)
    
    return True