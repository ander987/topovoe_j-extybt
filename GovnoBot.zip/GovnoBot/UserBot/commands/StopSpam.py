def cmd(vk, message, args, data, token, time, qiwi):
    info = data.get(token)
    for_all = None if message['from_id'] == message['peer_id'] else True
    if info["spam"]:
        info["spam"] = False
        data.set(token, info)
        inf = qiwi.get(token)
        inf["status"] = False
        qiwi.set(token, inf)

        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f"✅Ок, остановила спам."
        )
        time.sleep(1)
        vk.messages.delete(
           message_ids=message['id'],
           delete_for_all=for_all
        )

    return True