def cmd(vk, message, args, data, token):
    info = data.get(token)
    for_all = None if message['from_id'] == message['peer_id'] else True
    if info["status"]:
        info["status"] = False
        data.set(token, info)

        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f"✅Ок, убрала статус"
        )
        vk.messages.delete(
           message_ids=message['id'],
           delete_for_all=for_all
        )

    return True