from time import sleep
def cmd(vk, message, args):
    if args[1] = "час":
        text = " ".join(args[2:])
        vk.messages.send(
            peer_id=message["peer_id"],
            random_id=0,
            message=f"✅Ок, добавила таймер который сработает через 1 час и отправит сообщение «{text}»"
            )
        sleep(3600)
        vk.messages.send(
            peer_id=message["peer_id"],
            random_id=0,
            message=f"{text}"
            )
            
    if args[1] = "минута":
        text = " ".join(args[2:])
        vk.messages.send(
            peer_id=message["peer_id"],
            random_id=0,
            message=f"✅Ок, добавила таймер который сработает через 1 минуту и отправит сообщение «{text}»"
            )
        sleep(60)
        vk.messages.send(
            peer_id=message["peer_id"],
            random_id=0,
            message=f"{text}"
            )
            
    if args[1] = "сутки":
        text = " ".join(args[2:])
        vk.messages.send(
            peer_id=message["peer_id"],
            random_id=0,
            message=f"✅Ок, добавила таймер который сработает через сутки и отправит сообщение «{text}»"
            )
        sleep(86400)
        vk.messages.send(
            peer_id=message["peer_id"],
            random_id=0,
            message=f"{text}"
            )