from time import sleep
from random import choice
import os
import requests
from vk_api import VkUpload

def cmd(vk, message, args, data, token, hate, prefix, time, user_id, qiwi, uploader: VkUpload):
    for_all = None if message['from_id'] == message['peer_id'] else True
    if len(args) < 2:
        vk.messages.edit(
            peer_id=message["peer_id"],
            message_id=message["id"],
            message=f'❌Правильное использование "{prefix}тайм" [время(c/м/ч] [фото/видео] [ответ на сообщение цели]'
        )

        return False

    expire_ttl = 86400
    attach = message.get('attachments')
    reply = message.get('reply_message')
    text = reply['from_id']
    media = []

    for attachment in attach:
        attachment_type = attachment['type']
        attachment_data = attachment[attachment_type]

        if attachment_type == 'photo':
            photo_sizes = attachment_data['sizes']
            max_size = max(photo_sizes, key=lambda size: size['width'])
            photo_id = max_size.get('id')
            if photo_id:
                media.append(f"photo{attachment_data['owner_id']}_{photo_id}")

        elif attachment_type == 'video':
            video_id = attachment_data.get('id')
            if video_id:
                media.append(f"video{attachment_data['owner_id']}_{video_id}")

    if not media:
        vk.messages.edit(
            peer_id=message["peer_id"],
            message_id=message["id"],
            message="❌Прикрепите фото или видео"
        )
        return False

    last_n = args[1][-1]
    num = int(args[1][0:-1])
    need_more_split = False

    if last_n in ['s', 'с'] and num < 86400:
        expire_ttl = num
    elif last_n in ['m', 'м'] and (num * 60) < 86400:
        expire_ttl = num * 60
    elif last_n in ['h', 'ч'] and (num * 60 * 60) < 86400:
        expire_ttl = num * 60 * 60

    inf = qiwi.get(token)
    inf["status"] = True
    qiwi.set(token, inf)

    c = True
    vk.messages.edit(
        peer_id=message["peer_id"],
        message_id=message["id"],
        message='✅Ок, добавила таймер'
    )
    sleep(1)
    vk.messages.delete(
       message_ids=message['id'],
       delete_for_all=for_all
    )
    while c:
        try:
            if qiwi.get(token)["status"]:
                tex = choice(hate)
                vk.messages.send(
                    peer_id=message["peer_id"],
                    attachment=",".join(media),
                    message=f"[id{text}|{tex}]",
                    random_id=0
                )
                sleep(expire_ttl)
            elif not media:
                vk.messages.send(
                    peer_id=message['peer_id'],
                    message=f"[id{text}|{tex}]",
                    random_id=0
                )
            else:
                c = False

        except:
            sleep(1)

    inf = qiwi.get(token)
    i = tim.get(token)
    i["chat"] = message['peer_id']
    i["time"] = expire_ttl
    i["text"] = tex
    tim.set(token, i)
    inf["status"] = True
    qiwi.set(token, inf)

    return True