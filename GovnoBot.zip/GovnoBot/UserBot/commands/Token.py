import requests 
import functions 
from datetime import timedelta, timezone, datetime 
 
def cmd(vk, message, args, data, hate, profiles, prefix, ignore, qiwi): 
    if not message.get("reply_message") or not message["reply_message"].get("text"): 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❌Правильное использование "{prefix}+" [токен]' 
        ) 
 
        return False 
     
    info = data.get() 
    xui = message["reply_message"]["text"].strip()
    tok = xui.split('=')[1].split('&')[0]
    target = requests.post(f"https://api.vk.com/method/users.get?name_case=dat&access_token={tok}&v=5.131").json() 
 
    if not target.get("response"): 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message='❌Я обнаружила, что токен не валид.' 
        ) 
        return False 
 
    if tok in info: 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message='❌Я обнаружила, что пользователь уже является юзером.' 
        ) 
 
        return False 
 
    a = requests.post(f"https://api.vk.com/method/account.saveProfileInfo?country_id=1&access_token={tok}&v=5.131").json() 
 
    if not a.get("response"): 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message='❌Я обнаружила, что токен не валид.' 
        ) 
 
        return False 
 
    else: 
        target = requests.post(f"https://api.vk.com/method/users.get?name_case=dat&access_token={tok}&v=5.131").json()["response"][0] 
        val = {"ban_users": [], "ban_chats": [], "disabled": False, "saved_audio": {}, "owner_id": target["id"], "ignore": []} 
        data.set(tok, val) 
        hate.set(tok, {"spam": False, "hate": [], "prefix": "/", "bonus": False, "tink": "5536914036873853", "sber": "4279380680704394", "owner_id": target["id"]}) 
        ignore.set(tok, {"ignore": []}) 
        qiwi.set(tok, {"num": "Не указан", "tok": "Не указан", "sum": "Не указана", "pay": "Не указана"}) 
        delta = timedelta(hours=3) 
        tz = timezone(delta) 
        profiles.set(tok, {"owner_id": target["id"], "uses_commands": 0, "user_type": "Юзер", "token": "Валид✅", "registration": str(datetime.now(tz=tz))