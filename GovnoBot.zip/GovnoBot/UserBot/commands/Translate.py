from translate import Translator
def cmd(vk, message, args, prefix):
    
    translator = Translator(from_lang="en", to_lang="ru")
    text = " ".join(args[1:])
    text2 = translator.translate(text)
    
    if len(args) < 2:
        vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message=f'❌Правильное использование команды: {prefix}переведи "текст"' 
    )
    
    elif len(args) >= 2:
        vk.messages.edit( 
                peer_id=message["peer_id"],                 message_id=message["id"],  
                message=f'✅Результат перевода: {text2}'
        )