import random
import requests
from vk_api import VkUpload

def cmd(vk, message, args, uploader: VkUpload):
    vk.messages.edit(
        message_id=message['id'], 
        peer_id=message['peer_id'], 
        message='✅Идет генерация тянки...'
    )

    random_int = random.randrange(1, 99999)
    r = requests.get('https://www.thiswaifudoesnotexist.net/example-' + str(random_int) + '.jpg', stream=True)
    out = open("tyan.png", "wb")
    out.write(r.content)
    out.close()
    image = "tyan.png"
    uploaded = uploader.photo_messages(image, peer_id=message['peer_id'])[0]
    attach = f"photo{uploaded['owner_id']}_{uploaded['id']}"
    vk.messages.edit(
        message_id=message['id'], 
        peer_id=message['peer_id'], 
        message='✅Сгенерированная тянка:', 
        attachment=attach
    )
