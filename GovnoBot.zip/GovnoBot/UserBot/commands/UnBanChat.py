import config
import functions


def cmd(api, message, data, token):
    info = data.get(token)

    if not (message['peer_id'] in info["ban_chats"]):
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['invalid']} Я обнаружила, что данной беседе не ограничен доступ к боту."
        )
        return

    info["ban_chats"].remove(message['peer_id'])
    edit = data.set(token, info)

    if edit:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['success']} Ок, разблокировала данной беседе доступ к боту!"
        )
    else:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['error']} Данную беседу не получилось разблокировать. Возможно данные повреждены."
        )

    return
