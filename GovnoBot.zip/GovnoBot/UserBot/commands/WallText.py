from random import choice
from time import sleep
def cmd(vk, message, args, user_id, hate, admins):
    
    if len(args) <= 1:
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❌Правильное использование команды: валлтекст [ссылка] [кол_во] [текст]'
            )
        return False
        
    if user_id in admins:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Хуйлуша, ты кому спамить собрался, ливнул нахуй.'
        )
        return False
    
    else:
        target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"✅Ок, запустила спам постами на [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]"
            )
            
        text = " ".join(args[3:])
            
        for _ in range(int(args[2])):
            vk.wall.post(
                owner_id=user_id,
                message=text
                )
            sleep(0.1)