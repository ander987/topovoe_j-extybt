import vk_api
import datetime
import time
from PIL import Image, ImageDraw, ImageFont

def cmd(vk, message, args)
    try:
        api.photos.delete(owner_id=api.token['user_id'], photo_id=photo_id)
    except vk_api.exceptions.ApiError as e:
        print(f"Ошибка при удалении обложки: {e}")
        return False
    
    try:
        response = api.photos.save(owner_id=api.token['user_id'], photo=photo_id)
        photo = response[0]
        
        api.account.saveProfileInfo(
            photo_id=photo['id']
        )
        
        print("Обложка успешно установлена")
        return True
    except vk_api.exceptions.ApiError as e:
        print(f"Ошибка при установке обложки: {e}")
        return False

def generate_cover_with_datetime():
    width = 1590
    height = 400
    image = Image.new('RGB', (width, height), color=(255, 255, 255))
    
    font = ImageFont.truetype('arial.ttf', size=100)
    current_datetime = datetime.datetime.now().strftime('%Y-%m-%d %H:%M')
    
    draw = ImageDraw.Draw(image)
    
    text_color = (0, 0, 0)
    text_position = (100, 100)
    
    draw.text(text_position, current_datetime, fill=text_color, font=font)
    
    return image

while True:
    cover_image = generate_cover_with_datetime()
    
    file_name = 'cover.jpg'
    cover_image.save(file_name)
    
    upload_url = vk.photos.getOwnerCoverPhotoUploadServer()['upload_url']
    upload_response = vk.http.post(upload_url, files={'photo': open(file_name, 'rb')}).json()
    
    vk.upload_response['photo']
    
    time.sleep(60)
