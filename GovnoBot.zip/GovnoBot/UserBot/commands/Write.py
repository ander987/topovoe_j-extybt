def cmd(vk, message, args, data, token):
    info = data.get()
    info[i]
    self.vk = vk_api.VkApi(token=token, captcha_handler=captcha_handler)
	api = self.vk.get_api()
	text = " ".join(args[1:])
	
	api.messages.send(
	    peer_id=message['peer_id'],
	    random_id=0,
	    message=f"{text}"
	    )