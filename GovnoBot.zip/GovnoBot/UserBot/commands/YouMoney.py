from yoomoney import Client
def cmd(vk, message, args):
    
    token = "YOUR_TOKEN"
    client = Client(token)
    user = client.account_info()
    
    if user.account_status == "identified":
        status = "Индицирован"
    else: 
        status = "Не индицирован"
        
    if user.account_type:
        

        
    
    text = f"Ваш профиль YouMoney:\nНомер аккаунта: {user.account}\nБаланс: {user.balance}\nСтатус аккаунта: {status}\nТип аккаунта: {type}"
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"{text}"
        )

print("Account number:", user.account)
print("Account balance:", user.balance)
print("Account currency code in ISO 4217 format:", user.currency)
print("Account status:", user.account_status)
print("Account type:", user.account_type)
