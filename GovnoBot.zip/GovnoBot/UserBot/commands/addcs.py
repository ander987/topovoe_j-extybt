def cmd(vk, message, args, user_id):
    
    target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
        
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"✅Ок, добавила в чс [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]"
    )
    
    vk.account.ban(
        owner_id = user_id
        )