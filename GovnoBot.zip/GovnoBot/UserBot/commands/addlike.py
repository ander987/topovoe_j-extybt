import re
def cmd(vk,message, args,user_id):
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❌Правильное использование команды: спамком [количество] [текст] [ссылка на пост]"
        )

    elif len(args) >= 2:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, запустила накрутку комантариев."
        )

    text = " ".join(args[2:])

    for _ in range(int(args[1])):
        vk.wall.createComment(
            owner_id=user_id,
            post_id=2478,
            message=text
        )