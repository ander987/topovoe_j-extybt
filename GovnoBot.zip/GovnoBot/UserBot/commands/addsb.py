def cmd(vk, message, args, data, token, prefix):
    if len(args) < 2:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование команды "{prefix}сетсбер [текст]"'
        )

        return False

    text = " ".join(args[1:])
    info = data.get(token)
    if text == "дефолт":
        if info["sber"] == "4279380680704394":
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='❌Я обнаружила, что у вас и так дефолтная карта'
            )
            return False
        
        else:
            info["sber"] = "4279380680704394"
            data.set(token, info)
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='✅Ок, установила дефолтную карту "4279380680704394"'
            )
            return True

    else:
        info["sber"] = text + " "
        data.set(token, info)

    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message=f'✅Ок, сменила карту на "{text}"!'
    )

    return True