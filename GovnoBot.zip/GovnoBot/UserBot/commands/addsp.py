def cmd(vk, message, args, data1, data2, profiles, prefix, user_id, admins, data_admins):
    
    if message["from_id"] not in (data_admins.get("admins") + admins) and user_id != message["from_id"]:
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='❎Данную команду могут использовать только админы.'
        )
    
    if (len(args) <= 1 or not args[1].isdigit()) and not user_id:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование "{prefix}+спонсор" [айди]/ответ на сообщение'
        )

        return False
    
    target = vk.users.get(user_id=user_id, name_case="dat", random_id=0)

    if target == []:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я не нашла пользователя с таким айди.'
        )

        return False
    
    info1 = data2.get("sp")
    if user_id in info1:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я обнаружила, что пользователь уже спонсор.'
        )

        return False
    
    if target[0].get("deactivated"):
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Похоже, что [id{user_id}|Пользователь] заблокирован.'
        )

        return False
    
    info = data1.get()
    ids = [info[i]["owner_id"] for i in list(info)]

    if user_id not in ids:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я обнаружила, что пользователь не зарегистрирован в боте.'
        )

        return False

    print(target)

    info1.append(user_id)
    data2.set("sp", info1)

    info = profiles.get()
    user = [{i: info[i]} for i in info if user_id == info[i]["owner_id"]][0]
    key = list(user)[0]
    if user[key]["user_type"] != "Разработчик":
        user[key]["user_type"] = "Спонсор"
        profiles.set(key, user[key])

    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message=f"✅Ок, выдала спонсора [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]."
    )

    return True