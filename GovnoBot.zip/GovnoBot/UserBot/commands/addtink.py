def cmd(vk, message, args, data, token, prefix):
    if len(args) < 2:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование команды "{prefix}сеттиньк [текст]"'
        )

        return False

    text = " ".join(args[1:])
    info = data.get(token)
    if text == "дефолт":
        if info["tink"] == "5536914036873853":
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='❌Я обнаружила, что у вас и так дефолтная карта'
            )
            return False
        
        else:
            info["tink"] = "5536914036873853"
            data.set(token, info)
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message='✅Ок, установила дефолтную карту "5536914036873853"'
            )
            return True

    else:
        info["tink"] = text + " "
        data.set(token, info)

    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message=f'✅Ок, сменила карту на "{text}"!'
    )

    return True
    