from time import sleep
def cmd(vk, message, args):
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"🔴"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"🟡"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"🟢"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"BasRP"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"basrp"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"BasRP"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"basrp"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"BasRP"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"🔊🔊🔊"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Игровой проект GTA"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"тематики АВТОЗВУКА"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"🔊🔊🔊"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"BASRP ТОП"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"📢📢📢"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Играй у нас"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Держи нашу группу ВК"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"⚜️BasRP MTA:SA⚜️"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"✅ BasRP: @bass_auto_style"
        )