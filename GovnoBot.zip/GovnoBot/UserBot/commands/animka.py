from time import sleep
def cmd(vk, message, args, bot):
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"О"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Об"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обр"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обра"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обраб"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обрабо"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработ"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработк"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка т"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка тр"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка тре"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка трек"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка трека"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка трека B"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка трека By"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка трека By K"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка трека By Ku"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка трека By Kul"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка трека By Kuli"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработка трека By Kulik"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"🧨By Kulik"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"By Kulik🧨"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"By Kulik"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"🧨By Kulik🧨"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Обработки тут: @lowbass.kulik"
        )
    sleep(0.7)