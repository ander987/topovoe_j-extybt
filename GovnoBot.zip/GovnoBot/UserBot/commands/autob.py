from time import sleep

def cmd(vk, message, args, data, token, prefix, time):
    for_all = None if message['from_id'] == message['peer_id'] else True

    info = data.get(token)
    info["bonus"] = True
    data.set(token, info)
    
    c = True
    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message='✅Ок, запустила автосбор бонуса'
    )
    time.sleep(1)
    vk.messages.delete(
       message_ids=message['id'],
       delete_for_all=for_all
        )

    i = 0
    while i < 10:
        try:
            if data.get(token)["bonus"]:
                vk.messages.send(
                    peer_id=message["peer_id"],  
                    message="бонус",
                    random_id=0
                )
                sleep(86460)
                i += 1
            else:
                i = 10

        except:
            sleep(1)
            
    info = data.get(token)
    info["bonus"] = True
    data.set(token, info)
    
    return True