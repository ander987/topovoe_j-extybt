def cmd(vk, message, args, data, token):
    if args[1] == "ответы":