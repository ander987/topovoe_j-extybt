from time import sleep
def cmd(vk, message, args, data, token):
    info = data.get(token)
    info["st"] = True
    data.set(token, info)

    c = True
    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message='✅Ок, запустила статус гуля'
    )
    time.sleep(0.5)
    vk.messages.delete(
       message_ids=message['id'],
       delete_for_all=for_all
        )
    while c:
        try:
            if num <= 0:
                num = 1000
            if data.get(token)["spam"]:
                vk.messages.send(
                    peer_id=message["peer_id"],  
                    message=f"{num} - 7",
                    random_id=0
                )
                sleep(0.3)