def cmd(vk, message, args):
    if len(args) <= 1:
        vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"❌Правильное использование команды: «бинд» [текст] [команда]"
            )
        return False
        
    info = data.get(token)
    text = " ".join(args[1:])
    info["beand"] = text
    data.set(token, info)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id']
        message=f"✅Ок добавила бинд {text}"
        )