def cmd(vk, message, args, owner_id):
    
    target = vk.users.get(user_id=user_id, name_case="dat", random_id=0)
    
    
    vk.account.ban(
        owner_id=message['target']
        )
            
            
    vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"Ок, добавила в чс"
        )