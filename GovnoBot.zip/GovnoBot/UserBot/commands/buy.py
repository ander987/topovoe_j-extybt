import os
import config
import requests
from vk_api import VkUpload
from time import sleep
import re
from random import choice


def cmd(api, message, args):
    if len(args) != 4 or args[0].lower() != 'ркупить':
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"❌правильное использование: ркупить [айди] [первое число] [второе число]",
            reply_to=message['id']
        )
        return
    
    text = " ".join(args[1:3])
    first_num = args[3]
    second_num = args[2]
    for i in range(int(first_num), int(second_num) + 1):
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"ркупить {text} {i}"
        )
        sleep(0.5)
    
    api.messages.send(
        peer_id=message['peer_id'],
        random_id=0,
        message=f"✅Сообщения отправлены."
    )