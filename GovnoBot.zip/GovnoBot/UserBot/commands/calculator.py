def cmd(vk, message, args):
    if len(args) < 2:
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❌Правильное использование команды реши [пример]'
        )
    else:
        expr = " ".join(args[1:])
        try:
            result = eval(expr)
            vk.messages.send( 
                peer_id=message["peer_id"],  
                random_id=0,  
                message=f'✅Результат: {result}'
            )
        except:
            vk.messages.send( 
                peer_id=message["peer_id"],  
                random_id=0,  
                message=f'❌Ошибка: некорректное выражение "{expr}"\nУчтите, в команде используются следующие символы:\n• «+» - Сложение\n• «-» - Вычитание\n• «*» - Умножение\n• «/» - Деление'
            )