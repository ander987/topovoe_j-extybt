def cmd(vk, message, args):
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peeer_id'],
            message_id=message['id'],
            message=f"❌Правильное использование команды: +чатадм [пользователь]"
            )
        return
            
    if len(args) >= 2:
        vk.messages.addchatadm(
            user_id=user_id,
            chat_id=peer_id - 20000000
            )
            
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, выдала админку"
            )
        return
    if args[0] = "-чатадм":
        vk.messages.delchatadm(
            user_id=user_id,
            chat_id=peer_id - 2000000000
            )
        return
        