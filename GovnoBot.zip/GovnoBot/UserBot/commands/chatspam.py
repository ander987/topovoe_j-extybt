from random import choice
from time import sleep
def cmd(vk, message, args, user_id, hate):
    
    if len(args) <= 1:
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❌Правильное использование команды: чатспам [кол-во]'
            )
            
    elif len(args) >= 1:
            
        target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
    
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"✅Ок, запустила спам названиями"
            )
            
        for _ in range(int(args[1])):
            vk.messages.editChat(
                chat_id=message['peer_id']-2000000000,
                title=choice(hate)
                )
            sleep(0.1)