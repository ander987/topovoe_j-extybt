def cmd(vk, message, args, data, token):
    info = data.get(token)
    info["spam"] = True
    data.set(token, info)
    inf = data.get(token)
    tok = inf["tok"]
    phone = inf["num"]
    price = " ".join(args[2:])
    api = QApi(token=tok, phone=phone)
    comment = api.bill(price)
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"⏳Приём платежа на сумму: {price}р\nКомментарий для перевода: {comment}\nРеквезиты: {phone}\nПроверка платежа запущена!"
            )
            
    api.start()
        
    while True:
        if api.check(comment):
            vk.message.send(
                peer_id=message['peer_id'],
                random_id=0,
                message="✅Платёж прошёл успешно!"
                )
            break
        time.sleep(1)
    api.stop()