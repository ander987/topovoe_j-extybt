from requests import post, get
def cmd(vk, message, args):

    hella_token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ0b2tlbiI6IjQ0MTg0NjU1OV8xNjc0NTkyMjg1In0.30-opRsrVxyNSbf09WI7nhM3KK5efWn733zr3HtxnPM" 
def generation_quote(event):
    params = {'v': 1, 'access_token': hella_token, 'format_date': '%d.%m.%Y в %H:%M', 'background': 17}
    files = []
    if 'reply_message' in event:
        event = event['reply_message']
        params['member_id'] = event['from_id']
        if len(event['attachments']) > 0:
            event = event['attachments']
            if event[0]['type'] == 'sticker':
                event = event[0]['sticker']
                sticker = get(event['images_with_background'][-1]['url']).content
                text = " ".join(args[1:])
                files.append(("sticker_bytes", ("sticker.png", sticker)))
        else:
            if len(event['text']) > 0:
                params['text'] = event['text']
            else:
                params['text'] = '...'
    else:
        return 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'⚠ Укажите сообщение из которого необходимо создать цитату'
            )
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'⏱ Идёт генерация цитаты...'
            )
    try:
        if params['member_id'] < 0:
            user_get = vk.groups.getById(group_id=abs(params['member_id']), fields='photo_400_orig,screen_name')
            user_get = user_get[0]
        else:
            user_get = vk.users.get(user_id=params['member_id'], fields='photo_400_orig, screen_name')[0]
    except Exception as _:
        return 
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'⚠ Произошла ошибочка'
            )
    if 'deactivated' not in user_get:
        if user_get['screen_name'] != f'id{params["member_id"]}':
            params['screen_name'] = user_get['screen_name']
        else:
            params['screen_name'] = 'qwertyqwertyqwerty'
        if params['member_id'] > 0:
            params['name'] = f'{user_get["first_name"]} {user_get["last_name"]}'
        else:
            params['name'] = f'{user_get["name"]}'
        ava_bytes = get(user_get["photo_400_orig"]).content
        files.append(("ava_bytes", ("ava.png", ava_bytes)))
    else:
        return
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'⚠ Ошибка: пользователь удален'
            )
    res = post('http://api-meow.hella.team/method/GenerationQuotes', files=files,
               params=params).content
    upload_server = vk.photos.getMessagesUploadServer(peer_id=event.peer_id)['upload_url']
    response_data = post(upload_server, files=[('file', ('file.png', res))]).json()
    quote = vk.photos.saveMessagesPhoto(server=response_data['server'], photo=response_data['photo'],
                                    hash=response_data['hash'])[0]
    vk.messages.edit(peer_id=event.peer_id, message_id=event.message_id,
                     keep_forward_messages=1, attachment=f"photo{quote['owner_id']}_{quote['id']}")