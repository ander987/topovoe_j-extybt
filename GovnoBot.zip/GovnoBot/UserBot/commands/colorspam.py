def cmd(vk, message, args, user_id, data, token):
    vk.messages.edit(
        message_id=message['id'], 
        peer_id=message['peer_id'], 
        message="🔃Собираю информацию..."
        ) 
        
    if len(args) == 1:
        field = ['id', 'first_name', 'last_name', 'last_seen', 'is_closed', 'blacklisted', 'bdate', 'about', 'blacklisted_by_me', 'city', 'home_town', 'last_seen', 'can_write_private_message', 'sex']
        info_f = vk.users.get(user_ids=user_id, fields=field)[0]
        
        
        if info_f['is_closed'] == 1:
            zak = '✅'
        else:
            zak = '❌'
        
        if info_f['blacklisted_by_me'] == 1:
            chs = '✅'
        else:
            chs = '❌'
            
        if info_f['blacklisted'] == 1:
            chs_me = '✅'
        else:
            chs_me = '❌'
            
        if info_f['can_write_private_message'] == 1:
            can_send_ls = '✅'
        else:
            can_send_ls = '❌'
            
        if info_f['sex'] == 1:
            sex = 'Женский'
        elif info_f['sex'] == 2:
            sex = 'Мужской'
        else:
            sex = 'Не указан'
            
        try:
            city = info_f['city']['title']
        except Exception:
            city = '❌'
            
        try:
            dr = info_f['bdate']
        except Exception:
            dr = '❌'
            
        try:
            profile_photo = vk.users.get(user_ids=user_id, fields=['photo_id'])[0]['photo_id']
        except Exception:
            profile_photo = ''
            
        try:
            lst = info_f['last_seen']['platform']
        except Exception as e:
            print(e)
            lst = '❌'
            
        if lst == 1:
            lst = 'Мобильная версия (Android)'
        elif lst == 2:
            lst = 'Iphone'
        elif lst == 3:
            lst = 'Ipad'
        elif lst == 4:
            lst = 'Android'
        elif lst == 5:
            lst = 'Windows Iphone'
        elif lst == 6:
            lst = 'Windows 10'
        elif lst == 7:
            lst = 'Полная версия сайта'
        else:
            lst = 'скрыто'
            
        if zak == '✅':
            friends = '❌'
        elif zak == '❌':
            friends = vk.friends.get(user_id=user_id)['count']
            
        try:
            status_us = vk.status.get(user_id=user_id)
        except Exception as e:
            status_us = ''
            
        try:
            subs_info = vk.users.getFollowers(user_id=user_id)['count']
        except:
            subs_info = '?'
        
        info = '================================\n| ID @id' + str(user_id) + ' (пользователя): ' + str(info_f['id']) + '| ' + '\n| Имя: ' + str(info_f['first_name']) + '| ' + '\n| Фамилия: ' + str(info_f['last_name']) + '| ' + '\n| Пол: ' + str(sex) + '| ' + '\n| Количество друзей: ' + str(friends) + '| ' + '\n| Количество подписчиков: ' + str(subs_info) + '| ' + '\n| Был в сети откуда: ' + str(lst) + '| ' + '\n| Город: ' + str(city) + '| ' + '\n| День рождения: ' + str(dr) + '| ' + '\n| Закрыто лс: ' + str(can_send_ls) + '| ' + '\n| Закрытый профиль: ' + str(zak) + '| ' + '\n| Он у Вас в чс: ' + str(chs) + '| ' + '\n| Вы у него в чс: ' + str(chs_me) + '| ' + '\n| Статус пользователя: ' + str(status_us['text']) + '| ' + '\nФото профиля (если профиль не закрыт и если оно есть)| \n================================'
        
        vk.messages.edit(
            message_id=message['id'], 
            peer_id=message['peer_id'], 
            message=info, 
            attachment='photo' + str(profile_photo),
        ) 