from random import choice
def cmd(vk, message, args, user_id, hate):
    
    if len(args) <= 1:
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❌Правильное использование команды: +чат [название]'
            )
            
    elif len(args) > 1:
        target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
        text = " ".join(args[1:])
    
        vk.messages.createChat(
            user_ids=user_id,
            title=text
            )
        
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f"✅Ок, создала беседу под названием «{text}» и добавила туда [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]"
            )
            
    elif len(args) >= 2:
        target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
        text = " ".join(args[1:])
        ids = list(" ".join(args[2:]))
    
        vk.messages.createChat(
            user_ids=ids,
            title=text
            )
    