def cmd(vk, message, args, prefix):
    
    vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"✅Покупка TendoRP\nЦена: 100р\nСбербанк: 2202203689398891\nТинькофф: 5536 9140 2569 3734 \nПолучить токен ВКонтакте vk.cc/a6dCgm\nДальше отправьте свой токен в чат\n[vk.com/@tendorp-instrukciya-po-polucheniu-tokena|Инструкция получения токена]"
               )