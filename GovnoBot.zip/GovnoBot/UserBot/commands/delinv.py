def cmd(vk, message, args, data, token, user_id):
    
    info = data.get("user_ids")
    
    info.remove(user_id)
    dats.set("user_ids", info)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message="✅Ок, удалила."
        )