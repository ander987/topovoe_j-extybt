def cmd(vk, message, args, user_id, prefix):
    target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)

    try:
        status = vk.friends.areFriends(user_ids=user_id)[0]["friend_status"]
        if status == 0:
            vk.messages.edit(
                peer_id=message["peer_id"],
                message_id=message["id"],
                message=f"❌[id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}] не находится у вас в друзьях!",
            )
        else:
            vk.friends.delete(user_id=user_id)
            vk.messages.edit(
                peer_id=message["peer_id"],
                message_id=message["id"],
                message=f"✅Ок, удалила [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}] из друзей!",
            )
    except Exception as e:
        vk.messages.edit(
            peer_id=message["peer_id"],
            message_id=message["id"],
            message=f"{config.prefixes['error']} Ошибка: {str(e)}",
        )