import random

def cmd(vk, message, args, prefix, owner_id):
    if owner_id == message['from_id']:
        if len(args) < 2:
            vk.messages.edit(
                peer_id=message["peer_id"],
                message_id=message["id"],
                message=f'❌Правильное использование команды {prefix}игра орел/решка'
            )
        else:
            if args[1].lower() == "орел" or args[1].lower() == "решка":
                result = random.choice(["орел", "решка"])
                if args[1].lower() == result:
                    vk.messages.edit(
                        peer_id=message["peer_id"],
                        message_id=message["id"],
                        message=f"✅Выпало {result}. Поздравляю, вы выиграли!"
                    )
                else:
                    vk.messages.edit(
                        peer_id=message["peer_id"],
                        message_id=message["id"],
                        message=f"❌Выпало {result}. К сожалению, вы проиграли."
                    )
            else:
                vk.messages.edit(
                    peer_id=message["peer_id"],
                    message_id=message["id"],
                    message=f'❌Правильное использование команды {prefix}игра орел/решка'
                )
        return
        