def cmd(vk, message, args, data, token):
    info = data.get()
    token = info["owner_id"][i][0]
    