def cmd(vk, message, args, user_id, data, token):
    info = data.get()
    owner_id = user_id
    token = [info["owner_id"] for owner_id in info if user_id == info["owner_id"][i]][0] 
    target = vk.users.get(user_id=user_id, name_case="nom", random_id=0)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Токен пользователя [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]\n{token}"
        )
    