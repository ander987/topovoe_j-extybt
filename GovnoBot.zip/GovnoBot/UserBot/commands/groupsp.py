import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from random import choice

def cmd(vk, message, args, data, token, hate, user_id, prefix):
    
    if len(args) == 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Правильное использование: гспам [параметр]\n\nДоступные параметры:\nтокен - сменить токен сообщества\nайди - сменить айди сообщества\nпрофиль - сохранённые данные\nзапустить - начать спам"
            )
        return False
    
    info = data.get(token)
    tok = info["token"]
    sid = info["sid"]
    
    if args[1] == "профиль":
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"Данные для спама сохранённые в боте:\n|Токен сообщества: {tok}\n|Айди сообщества: {sid}"
            )
    
    if args[1] == "токен":
        t = " ".join(args[2:])
        info["token"] = t + ""
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="✅Токен сообщества изменён!"
            )
            
    if args[1] == "айди":
        te = " ".join(args[2:])
        info["sid"] = te + ""
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="✅Айди сообщества изменено!"
            )
    
    if args[1] == "запустить":
        GROUP_ID = sid
        TOKEN = tok
        vk_session = vk_api.VkApi(token=TOKEN)
        longpoll = VkBotLongPoll(vk_session, GROUP_ID)
        api = vk_session.get_api()
        for event in longpoll.listen():
            if event.type == VkBotEventType.MESSAGE_NEW:
                peer_id = event.obj.message["peer_id"]
                message = event.obj.message["text"]
                if message.startswith('гспам запустить'):
                    api.messages.send(
                        peer_id=peer_id,
                        random_id=0,
                        message=f"Ебашу!"
                        )
                    for _ in range(100):
                        api.messages.send(
                            peer_id=peer_id,
                            random_id=0,
                            message=choice(hate)
                            )
    