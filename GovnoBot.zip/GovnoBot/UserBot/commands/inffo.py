def cmd(vk, message, args, user_id):
    target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
    fields = 'bdate, city, country, education, followers_count'
    user_info = vk.users.get(user_ids=user_id, fields=fields)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Информация о пользователе: {user_info}"
        )