def cmd(vk, message, args, data, token):
    
    user_ids = data.get("user_ids")
    
    if args[1] == "список":
        users = []
        targets = vk.users.get(user_id=user_ids, random_id=0) if len(user_ids) > 0 else []
        for target in targets:
        users.append(f"[id{target['id']}|{target['first_name']} {target['last_name']}]")
        admins_message = "\n✅Список пользователей:\n" + "\n".join(users) if len(users) > 0 else ""
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{admins_message}"
            )
        return
            
    for user_id in user_ids:
        try:
            vk.messages.addChatUser(
                chat_id=message['peer_id']-2000000000,
                user_id=user_id
                )
            vk.messages.send(
                peer_id=message['peer_id'],
                random_id=0,
                message=f"✅Ок, добавила в беседу @id{user_id}"
                )
        except vk_api.exceptions.ApiError as e:
            vk.messages.send(
                peer_id=message['peer_id'],
                random_id=0,
                message=f"❌Пользователь @id{user_id} не добавлен\nошибка: {e}"
                )
            