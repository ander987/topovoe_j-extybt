def cmd(vk, message, args):
    
    conversation_info = vk.messages.getConversations(count=1)['items'][0]['conversation']

    members_count = conversation_info['chat_settings']['members_count']

    online_members_count = conversation_info['chat_settings']['online_members_count']
    
    title = conversation_info['chat_settings']['title']

    admin_ids = conversation_info['chat_settings']['admin_ids']
    admins = vk.users.get(user_ids=admin_ids)
    amd = admin['first_name'], admin['last_name']
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"✅Полученная информация о беседе:\n|Название беседы: {title}\n|Количество участников: {members_count}\n|Количество участников онлайн: {online_members_count}\n|Админы беседы: {adm}"
        )