import os
import config
import requests
from vk_api import VkUpload
from time import sleep
import re


def cmd(api, message, args, uploader: VkUpload, prefix):
    for_all = None if message['from_id'] == message['peer_id'] else True
    attach = message.get('attachments')
    reply = message.get('reply_message')
        
    if (len(attach) == 0 and reply is None) and args[1].isdigit():
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"{config.prefixes['error']} Необходимо прикрепить фотографию и написать: {prefix}накрутка [кол-во] [ссылка на альбом]",
            reply_to=message['id']
        )
        return

    try:
        if reply is not None:
            img = reply['attachments'][0]['photo']['sizes'].pop()['url']
        else:
            img = attach[0]['photo']['sizes'].pop()['url']
    except:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"{config.prefixes['error']} Необходимо прикрепить фотографию и написать: {prefix}накрутка [кол-во] [ссылка на альбом]",
            reply_to=message['id']
        )
        return

    filename = "files/" + os.path.basename(img).split('?')[0]
    if len(filename.split('.')) < 2: filename += ".png"

    r = requests.get(img)
    with open(filename, 'wb') as f:
        f.write(r.content)

    album = re.findall(r"https://vk.com/album\d{,}_(\d{,})", args[2]) # https://vk.com/album441846559_{args[1:]}
    
    api.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'✅Ок, запустила накрутку.'
            )
    
    if len(album) == 0:
        api.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"{config.prefixes['error']} Необходимо прикрепить фотографию и написать: {prefix}накрутка [кол-во] [ссылка на альбом]",
            reply_to=message['id']
        )
        return

    for _ in range(int(args[1])):
        uploader.photo(photos=filename, album_id=album[0])