from vk_api import VkUpload
def cmd(vk, message, args, uploader: VkUpload):
    
    img = attach[0]['photo']['sizes'].pop()['url']
    filename = "mems/" + os.path.basename(img).split('?')[0]
    uploaded = uploader.photo_messages(filename, peer_id=message['peer_id'])[0]
    attach = f"photo{uploaded['owner_id']}_{uploaded['id']}"
    os.remove(filename)
    vk.messages.send(
        peer_id=message['peer_id'],
        random_id=0,
        attachment=attach,
        reply_to=message['id']
    )