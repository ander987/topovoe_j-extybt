import time
import config
import functions


def cmd(api, message, args, owner_id, admins, user_id, data, token):
    for_all = None if message['from_id'] == message['peer_id'] else True

    if message.get('reply_message') is not None:
        target = api.users.get(
            user_ids=message['reply_message']['from_id']
        )
    else:
        try:
            target = api.users.get(
                user_ids=functions.getUserId(args[1])
            )
        except:
            api.messages.edit(
                peer_id=message['peer_id'],
                message_id=message['id'],
                message=f"{config.prefixes['error']} Необходимо ответить на сообщение пользователя или указать на него ссылку: мут [пользователь]"
            )
            time.sleep(3)
            api.messages.delete(
                message_ids=message['id'],
                delete_for_all=for_all
            )
            return

    info = data.get(token)
    if info is None: info = []

    target = target[0]
    if target['id'] in info["ignore"]:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['invalid']} [id{target['id']}|{target['first_name']} {target['last_name']}] уже в муте"
        )
        return

    if owner_id == target['id']:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="❌нельзя мутить самого себя, дебил!"
        )
        return
    
    if user_id in admins:
        api.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я не могу замутить разработчика, соси.'
        )
        return

    info["ignore"].append(target['id'])
    edit = data.set(token, info)

    if edit:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"{config.prefixes['success']} [id{target['id']}|{target['first_name']} {target['last_name']}] теперь в муте!"
        )
    else:
        api.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"Пользователя {config.prefixes['error']} [id{target['id']}|{target['first_name']} {target['last_name']}] не получилось отправить в мут"
        )

    return