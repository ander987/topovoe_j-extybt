import time
def cmd(vk, message, args, data, token):
    
    info = data.get()
    ids = [info[i]["owner_id"] for i in list(info)]
    users = []
    uuser = len(users)
    start_time = time.time()
    st = time.time() - start_time