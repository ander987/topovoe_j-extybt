import requests
import functions
from datetime import timedelta, timezone, datetime

def cmd(vk, message, args, data, hate, profiles, prefix, ignore, qiwi, audio):
    if len(args) <= 1 or len(str(args)) < 85:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование "{prefix}+токен" [токен]'
        )

        return False
    
    info = data.get()
    target = requests.post(f"https://api.vk.com/method/users.get?name_case=dat&access_token={args[1]}&v=5.131").json()

    if not target.get("response"):
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я обнаружила, что токен не валид.'
        )
        return False

    if args[1] in info:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я обнаружила, что пользователь уже является юзером.'
        )

        return False

    a = requests.post(f"https://api.vk.com/method/account.saveProfileInfo?country_id=1&access_token={args[1]}&v=5.131").json()

    if not a.get("response"):
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message='❌Я обнаружила, что токен не валид.'
        )

        return False

    else:
        target = requests.post(f"https://api.vk.com/method/users.get?name_case=dat&access_token={args[1]}&v=5.131").json()["response"][0]
        val = {"ban_users": [], "ban_chats": [], "disabled": False, "saved_audio": {}, "owner_id": target["id"], "ignore": []}
        data.set(args[1], val)
        hate.set(args[1], {"spam": False, "hate": [], "prefix": "/", "bonus": False, "tink": "5536914036873853", "sber": "4279380680704394"})
        ignore.set(args[1], {"ignore": []})
        qiwi.set(args[1], {"num": "Не указан", "tok": "Не указан", "sum": "Не указана"})
        audio.set(args[1], {"saved_audio": {}})
        delta = timedelta(hours=3)
        tz = timezone(delta)
        profiles.set(args[1], {"owner_id": target["id"], "uses_commands": 0, "user_type": "Юзер", "token": "Валид✅", "registration": str(datetime.now(tz=tz))[:-13], "active": 1})
        print(target)
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f"✅Ок, выдала [id{target['id']}|{target['first_name']} {target['last_name']}] доступ к TendoRP."
        )

    return True