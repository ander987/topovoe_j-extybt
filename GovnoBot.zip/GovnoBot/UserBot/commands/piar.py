from time import sleep
def cmd(vk, message, args):
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"T"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Te"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Ten"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Tend"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"Tendo"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoR"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\n"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nh"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nht"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhtt"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttp"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps:"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps:/"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://v"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://vk"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://vk."
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://vk.com/"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://vk.com/l"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://vk.com/lp"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://vk.com/lpt"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://vk.com/lpte"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://vk.com/lptendo"
        )
    sleep(0.7)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"TendoRP\nhttps://vk.com/lptendorp"
        )
    sleep(0.7)