def cmd(vk, message, args, time):

    time_start = time.time()

    vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message='Замеряю пинг...'
    )

    result = time.time() - time_start
    result = float('{:.1f}'.format(result))

    vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message=f'✅Понг!\nВремя обработки команды: {result}сек.' 
    )