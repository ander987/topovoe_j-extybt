def cmd(vk, message, args, user_id, data):
    info = data.get()
    ids = [info[i]["owner_id"] for i in list(info)]
    
    while True:
        if user_id not in ids:
            vk.messages.removeChatUser(
                chat_id=742,
                user_id=user_id
            )
            vk.messages.edit(
                peer_id=message["peer_id"],
                message_id=message["id"],
                message=f"Пользователь не являетсяюзером бота, удаляю."
            )