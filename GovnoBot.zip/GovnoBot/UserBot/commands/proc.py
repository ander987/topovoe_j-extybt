def cmd(vk, message, args, data, token):
    
    info = data.get(token)
    
    if info["status"] == False:
        info["status"] = True
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, запустила автостатус!"
            )
        
    else:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❌Статус уже запущен!"
            )
    