import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
def cmd(vk, message, args, data, token):
    
    info = data.get(token)
    tok = info["token"]
    sid = info["sid"]
    uid = info["uid"]
    text = info["text"]
    
    if len(args) == 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❌Правильное использование: рассылка [параметр]\n\nДоступные параметры:\nпрофиль - посмотреть данные указанные для рассылки\nтокен - сменить токен сообщества\nайди - сменить айди сообщества\nлоги - сменить айди пользователя которому будут отправляться логи\nначать - начать рассылку\nтекст - сменить текст для рассылки"
            )
        return False
        
    if args[1] == "профиль":
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"Данные для рассылки сохранённые в боте:\n|Токен сообщества: {tok}\n|Айди сообщества: {sid}\n|Айди для логов: {uid}\n|текст рассылки: {text}"
            )
            
    if args[1] == "токен":
        t = " ".join(args[2:])
        info["token"] = t + ""
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="✅Токен сообщества изменён!"
            )
            
    if args[1] == "айди":
        te = " ".join(args[2:])
        info["sid"] = te + ""
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="✅Айди сообщества изменено!"
            )
            
    if args[1] == "логи":
        tet = " ".join(args[2:])
        info["uid"] = tet + ""
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="✅Айди пользователя изменено!"
            )
            
    if args[1] == "текст":
        tete = " ".join(args[2:])
        info["text"] = tete + ""
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="✅Текст рассылки изменён!"
            )
            
    if args[1] == "начать":
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, запустила рассылку от [https://vk.com/public{sid}|сообщества]"
            )
            
        GROUP_ID = sid
        TOKEN = tok
        vk_session = vk_api.VkApi(token=TOKEN)
        longpoll = VkBotLongPoll(vk_session, GROUP_ID)
        api = vk_session.get_api()
        subscribers = api.groups.getMembers(group_id=GROUP_ID, v='5.131')['items']
        for subscriber in subscribers:
            try:
                api.messages.send(
                    peer_id=subscriber,
                    random_id=0,
                    message=f"{text}"
                    )
                api.messages.send(
                    peer_id=uid,
                    random_id=0,
                    message=f"✅Сообщение отправлено пользователю @id{subscriber}"
                    )
            except Exception as e:
                api.messages.send(
                    peer_id=uid,
                    random_id=0,
                    message=f"❌Ошибка при отправке сообщения пользователю @id{subscriber}: {e}"
                    )