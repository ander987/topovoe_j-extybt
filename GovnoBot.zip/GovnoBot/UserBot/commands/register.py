def cmd(vk, message, args, prefix, data, token, qiwi):
    info = data.get(token)
    inf = qiwi.get(token)
    phone = inf["num"]
    sber = info["sber"]
    tink = info["tink"]
    
    vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"✅Покупка TendoRP\nЦена: 199р\nСбербанк: {sber} \nТинькофф: {tink} \nQiwi: {phone}\nПолучить токен ВКонтакте: vk.cc/a6dCgm\nДальше отправьте свой токен в чат\n[vk.com/@lptendorp-instrukciya-polucheniya-tokena|Инструкция получения токена]"
               )