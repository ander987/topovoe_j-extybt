import requests
import functions
from datetime import timedelta, timezone, datetime

def cmd(vk, message, args, data, hate, profiles, prefix, ignore, qiwi, token):
    if len(args) <= 1 or len(str(args)) < 85:
        vk.messages.send(
            peer_id=message["peer_id"], 
            random_id=0, 
            message=f'❌Правильное использование "{prefix}токен" [токен]'
        )

        return False
        
    info = data.get(token)
    target = requests.post(f"https://api.vk.com/method/users.get?name_case=dat&access_token={args[1]}&v=5.131").json()

    if not target.get("response"):
        vk.messages.send(
            peer_id=message["peer_id"], 
            random_id=0, 
            message='❌Я обнаружила, что токен не валид.'
        )
        return False

    if args[1] in info:
        vk.messages.send(
            peer_id=message["peer_id"], 
            random_id=0, 
            message='❌Я обнаружила, что пользователь уже является юзером.'
        )

        return False

    a = requests.post(f"https://api.vk.com/method/account.saveProfileInfo?country_id=1&access_token={args[1]}&v=5.131").json()

    if not a.get("response"):
        vk.messages.send(
            peer_id=message["peer_id"], 
            random_id=0, 
            message='❌Я обнаружила, что токен не валид.'
        )

        return False

    else:
        target = requests.post(f"https://api.vk.com/method/users.get?name_case=dat&access_token={args[1]}&v=5.131").json()["response"][0]
        data.set(args[1])
        hate.set(args[1])
        ignore.set(args[1])
        delta = timedelta(hours=3)
        tz = timezone(delta)
        profiles.set(args[1])
        print(target)
        vk.messages.send(
            peer_id=message["peer_id"], 
            random_id=0, 
            message=f"✅Ок, выдала [id{target['id']}|{target['first_name']} {target['last_name']}] доступ к TendoRP."
        )

    return True