import asyncio
import sys
import os
import psutil

def cmd(vk, message, args):
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message="🔃Перезапускаю бота\nБудут перезагружены файлы: «bot.py» «main.py»"
        )
        
    SCRIPTS = [
    'bot.py',
    'main.py'
    ]

    MAX_THREADS = 100

    async def waiter(sc, p):
        await p.wait()
    return sc, p

    async def main():
        waiters = []
    
        for sc in SCRIPTS:
            p = await asyncio.create_subprocess_exec(sys.executable, sc)
            print('Started', sc)
            waiters.append(asyncio.create_task(waiter(sc, p)))

        try:
            await asyncio.gather(*waiters)
        except KeyboardInterrupt:
            print("Interrupted")
            for p in psutil.process_iter():
                try:
                    if p.name() == "python":
                        p.terminate()
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass

        # Wait for processes to terminate
            for p in psutil.process_iter():
                try:
                    if p.name() == "python":
                        p.wait(1)
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    pass

        # Restart processes
            for i, sc in enumerate(SCRIPTS):
                p = await asyncio.create_subprocess_exec(sys.executable, sc)
                print('Restarted', sc)
                waiters[i] = asyncio.create_task(waiter(sc, p))

            await asyncio.gather(*waiters)

    if __name__ == "__main__":
        asyncio.run(main())