def cmd(vk, message, args):
    
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❌Правильное использование: обрезка [токен]"
            )
            
    elif len(args) >= 2:
        token = args[1].split('=')[1].split('&')[0]
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, вот обрезанный токен:\n«{token}»"
            )
    
    