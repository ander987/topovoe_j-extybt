from time import sleep
def cmd(vk, message, args):
    x = " ".join(args[1:])
    if len(args) <= 1:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message="❌Правильное использование: рест [скрипт]\nДоступные скрипты:\nmain.py\nma.py\ntg.py\nbot.py"
            )
        return False
        
        
    vk.messages.send(
        peer_id=-219384588,
        random_id=0,
        message=f"Перезапустить {x}"
        )
        
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"⚙️Перезапускаю {x}"
        )
    sleep(1)
    
    vk.messages.edit(
        peer_id=message['peer_id'],
        message_id=message['id'],
        message=f"✅Файл {x} перезапущен."
        )
            