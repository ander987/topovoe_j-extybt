def cmd(vk, message, user_id, owner_id):
    
    target = vk.users.get(user_id=user_id, name_case="dat", random_id=0)
    targets = vk.users.get(user_id=owner_id, name_case="dat", random_id=0)
    text = " ".join(args[1:])
    
    vk.message.send(
        peer_id=message['peer_id'],
        random_id=0,
        message=f"[id{targets[0]['id']}|{targets[0]['first_name']} {targets[0]['last_name']}] {text} [id{target[0]['id']}|{target[0]['first_name']} {target[0]['last_name']}]"
    )


