from time import sleep
from random import choice

def cmd(vk, message, args, data, token, hate, prefix, time):
    for_all = None if message['from_id'] == message['peer_id'] else True
    target = vk.users.get(user_id=user_id, name_case="acc", random_id=0)
    if len(args) < 3:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование "{prefix}спам оск" [интервал(c/м/ч)]'
        )

        return False

    expire_ttl = 86400
    try:
        last_n = args[2][-1]
        num = float(args[2][0:-1])
        need_more_split = False

        if last_n in ['s', 'с'] and num < 86400: 
            expire_ttl = num
        elif last_n in ['m', 'м'] and (num * 60) < 86400:
            expire_ttl = num * 60
        elif last_n in ['h', 'ч'] and (num * 60 * 60) < 86400:
            expire_ttl = num * 60 * 60
        else:
            vk.messages.edit(
                peer_id=message["peer_id"], 
                message_id=message["id"], 
                message=f'❌Правильное использование "{prefix}спам оск" [интервал(c/м/ч)]'
            )

            return False

    except:
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f'❌Правильное использование "{prefix}спам оск" [интервал(c/м/ч)]'
        )

        return False
    
    

    info = data.get(token)
    info["spam"] = True
    data.set(token, info)

    c = True
    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message='✅Ок, запустила спам.'
    )
    vk.messages.delete(
       message_ids=message['id'],
       delete_for_all=for_all
        )
    while c:
        try:
            if data.get(token)["spam"]:
                vk.messages.send(
                    peer_id=message["peer_id"],  
                    message=choice([id{target[0]['id']}|{target[0]['hate']}]),
                )
                sleep(expire_ttl)
            else:
                c = False

        except:
            sleep(1)
            
    info = data.get(token)
    info["spam"] = True
    data.set(token, info)
    
    return True