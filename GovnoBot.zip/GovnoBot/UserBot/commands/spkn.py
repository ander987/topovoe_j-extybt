from time import sleep
def cmd(vk, message, args, time):
    
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️Спокойной ночи зайка ❤️'
            )
    time.sleep(0.6)
    
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'💓Спокойной ночи солнышко 💓'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'💙Спокойной ночи принцесса💙'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'💛Спокойной ночи ангелочек💛'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'💜Спокойной ночи солнышко💜'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'💚Спокойной ночи бусинка💚'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'💗Спокойной ночи симпатяжка💗'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'🤍Спокойной ночи котёнок🤍'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️Я❤️'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'💙Тебя💙'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'💋Люблю'
            )
    time.sleep(0.6)
            
    vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'❤️'
            )
    time.sleep(0.6)