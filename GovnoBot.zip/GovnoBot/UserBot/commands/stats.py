def cmd(vk, message, args, data, token):
    info = data.get(token)
    
    if args[1] == "+":
        info["bonus"] == True
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, добавила авто статус."
            )
        
    if args[1] == "-":
        info["bonus"] == False
        data.set(token, info)
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"✅Ок, убрала авто статус."
            )