def cmd(vk, message, args, prefix):
    
    text = " ".join(args[1:])
    
    if len(args) < 2:
        vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message=f'❌Правильное использование команды: {prefix}+статус "текст"' 
    )
        
    elif len(args) >= 2:
        vk.status.set(
            text = text
        )
        
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'✅Ок, установила статус "{text}"' 
    )
    
    if args(1) == "авто":
        current_date = date.today()
        current_date_time = datetime.datetime.now()
        current_time = current_date_time.time()
        while True:
            text = f"Сегодня: {current_date}\nВремя: {current_time}"
            vk.status.set(
            text = text
            )
            
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'✅Ок, установила статус' 
    )
        