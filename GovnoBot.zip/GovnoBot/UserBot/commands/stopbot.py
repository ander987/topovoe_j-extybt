import requests
import functions

def cmd(vk, message, args, data, hate, profiles, admins, prefix, user_id, owner_id):
    
    target = vk.users.get(user_id=user_id, random_id=0)[0]

    info = data.get()
    ids = [info[i]["owner_id"] for i in list(info)]
    
    if user_id != owner_id:
        vk.messages.edit(
            peer_id=message['peer_id'],
            message_id=message['id'],
            message=f"❌Вы можете удалить только себя!."
            )
            
    elif user_id == owner_id:
        token = [i for i in list(info) if info[i]["owner_id"] == user_id][0]

    if data.delete(token):
        hate.delete(token)
        profiles.delete(token)
        vk.messages.edit(
            peer_id=message["peer_id"], 
            message_id=message["id"], 
            message=f"✅Ок, удалила ваш токен из бота:("
        )