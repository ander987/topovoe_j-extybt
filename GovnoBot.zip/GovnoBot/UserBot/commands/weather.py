from pyowm import OWM
from pyowm.utils.config import get_default_config
def cmd(vk, message, args, prefix):

    config_dict = get_default_config()
    config_dict['language'] = 'ru'

    place = " ".join(args[1:])
    owm = OWM('9a81f570f816171393acc2963239db62', config_dict)
    mgr = owm.weather_manager()
    observation = mgr.weather_at_place(place)
    w = observation.weather

    t = w.temperature("celsius")
    t1 = t['temp']
    t2 = t['feels_like']

    wi = w.wind()['speed']
    humi = w.humidity
    cl = w.clouds
    st = w.status
    ti = w.reference_time('iso')
    pr = w.pressure['press']
    vd = w.visibility_distance
    
    vk.messages.edit(
        peer_id=message["peer_id"], 
        message_id=message["id"], 
        message=f'✅В городе {place} сейчас:\n🌡Температура: {t1}°C\n❄️Ощущается как: {t2}°C\n🌬️Скорость ветра: {wi}м/с\n🌀Давление: {pr} мм.рт.ст\n🌧️Влажность воздуха: {humi}%\n🌤️Видимость примерно: {vd} метров\n🌫️Общее описание погоды: {st}'
            )