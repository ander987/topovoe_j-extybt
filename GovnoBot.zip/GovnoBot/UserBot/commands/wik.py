import wikipedia
def cmd(vk, message, args, prefix):
    text = " ".join(args[1:])
    page = wikipedia.page(text)
    wikipedia.set_lang('ru')
    
    if len(args) < 2:
        vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message=f'❌Правильное использование команды {prefix} вики "запрос"'
            )
        
    if len(args) >= 2:
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'🗯Получаю информацию из Википедии...️'
            )
        vk.messages.edit( 
            peer_id=message["peer_id"],  
            message_id=message["id"],  
            message=f'✅Результат поиска по запросу "{text}":\n{page.summary}'
            )