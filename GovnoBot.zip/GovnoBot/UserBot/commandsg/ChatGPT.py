import openai
import time
import config

def cmd(vk, message, args):
    if len(args) == 1:
        vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message="❌Правильное использование: бот [вопрос/задача]"
        )
    
    elif len(args) >= 2:
        vk.messages.send(
            peer_id=message['peer_id'],
            random_id=0,
            message=f"🔃Ваш запрос принят и обрабатывается\nПодождите немного, время обработки 15-45сек."
            )
        
        tex = " ".join(args[1:])
        openai.api_key = config.gpt
        response = openai.Completion.create(
            model="text-davinci-003",
            prompt=tex,
            temperature=0.9,
            max_tokens=4000,
            top_p=1,
            frequency_penalty=0.0,
            presence_penalty=0.6,
        )
        otv = response['choices'][0]['text']
        
        # Если ответ превышает лимит длины сообщения ВКонтакте (4096 символов), отправляем его частями
        if len(otv) > 4096:
            parts = [otv[i:i+4096] for i in range(0, len(otv), 4096)]
            for i, part in enumerate(parts):
                try:
                	vk.messages.send(
                	    peer_id=message['peer_id'],
                        random_id=0,
                        message=f"✅Ответ от TendoRP\n{otv}\n\n@lptendorp"
                    )
                except Exception as e:
                    vk.messages.send(
                        peer_id=message['peer_id'],
                        random_id=0,
                        message=f"❌Ошибка. {str(e)}"
                        )
        else:
            try:
                vk.messages.send(
                    peer_id=message['peer_id'],
                    random_id=0,
                    message=f"✅Ответ от ChatGPT:\n{otv}\n@lptendorp"
                )
            except Exception as e:
                vk.messages.send(
                    peer_id=message['peer_id'],
                    random_id=0,
                    message=f"❌Ошибка: {e}"
                )
                