import random
def cmd(vk, message, args, owner_id):
    
    if owner_id == message['from_id']:
        if len(args) == 1:
            vk.messages.send(
                peer_id=message["peer_id"],
                random_id=0,
                message=f'❌Правильное использование: "инфа [событие]"'
            )

            return False

        percent = random.randint(1, 100)
        vk.messages.send(
            peer_id=message["peer_id"],
            random_id=0,
            message=f'✅Думаю, вероятность этого события {percent}%',
            reply_to=message['id']
        )
        return
    else:
        if len(args) == 1:
            vk.messages.send(
                peer_id=message["peer_id"],
                random_id=0,
                message=f'❌Правильное использование: "инфа [событие]"',
                reply_to=message['id']
            )

            return False

        percent = random.randint(1, 100)
        vk.messages.send(
            peer_id=message["peer_id"],
            random_id=0,
            message=f'✅Думаю, вероятность этого события {percent}%',
            reply_to=message['id']
        )