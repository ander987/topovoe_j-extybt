def get_commands(type_commands):
    commands = {
	    "public": [
	        {
	            "commands_alias": [f"жма"],
	            "description": "жмых голсового сообщения",
	        },
	        {
	            "commands_alias": [f"жмф"],
	            "description": "жмых фотографии",
	        },
	        {
	            "commands_alias": [f"тч"],
	            "description": "проверка пользователя на тестера вк",
	        },
	        {
	            "commands_alias": [f"вгс"],
	            "description": "конвертация трека в голосовое сообщение",
	        },
	        {
	            "commands_alias": [f"нег"],
	            "description": "первести фотогарфию в негатив",
	        },
	        {
	            "commands_alias": [f"бот"],
	            "description": "ChatGPT",
	        },
	        {
	            "commands_alias": [f"дем"],
	            "description": "создать демотиватор",
	        },
	        {
	            "commands_alias": [f"тч"],
	            "description": "проверить пользователя на тестера ВК",
	        },
	        {
	            "commands_alias": [f"стики"],
	            "description": "узнать количество стикеров пользователя",
	        },
	        {
	            "commands_alias": [f"инфо"],
	            "description": "узнать ID пользователя",
	        },
	        {
	            "commands_alias": [f"реши"],
	            "description": "решить пример",
	        },
	        {
	            "commands_alias": [f"вики"],
	            "description": "запрос в википедию",
	        },
	        {
	            "commands_alias": [f"инфа"],
	            "description": "вероятность случайного события",
	        },
	        {
	            "commands_alias": [f"погода"],
	            "description": "информация о погоде в выбранном городе",
	        },
	        {
	            "commands_alias": [f"рег"],
	            "description": "Получить ссылку для регистрации в боте",
	        },
	    ],
	    "private": [
	        {
	            "commands_alias": [f"бан"],
	            "description": "заблокировать доступ к боту пользователю (бот не будет реагировать на него)",
	        },
	        {
	            "commands_alias": [f"бан_чат"],
	            "description": "заблокировать чат (бот не будет в нем работать)",
	        },
	        {
	            "commands_alias": [f"префикс"],
	            "description": "сменить префикс",
	        },
	        {
	            "commands_alias": ["мпреф"],
	            "description": "посмотреть установленный на текущий момент префикс",
	        },
	        {
	            "commands_alias": [f"хейт"],
	            "description": "Хейт режим(вкл/выкл)",
	        },
	        {
	            "commands_alias": [f"-спам"],
	            "description": "Остановить спам",
	        },
	        {
	            "commands_alias": [f"спам оск"],
	            "description": "Спам оскорблениями",
	        },
	        {
	            "commands_alias": [f"префикс дефолт"],
	            "description": "Установить дефолтный префикс",
	        },
	        {
	            "commands_alias": [f"-префикс"],
	            "description": "Удалить префикс",
	        },
	        {
	            "commands_alias": [f"профиль"],
	            "description": "Посмотреть свой профиль в TendoRP",
	        },
	        {
	            "commands_alias": [f"пинг"],
	            "description": "Замерить пинг",
	        },
	        {
	            "commands_alias": [f"+статус"],
	            "description": "Установить статус",
	        },
	        {
	            "commands_alias": [f"+/-др"],
	            "description": "Добавить/Удалить пользователя из друзей",
	        },
	        {
	            "commands_alias": [f"+/-чс"],
	            "description": "Добавить/Удалить пользователя из чёрного списка",
	        },
	        {
	            "commands_alias": [f"переведи"],
	            "description": "Перевести текст с английского на русский язык",
	        },
	        {
	            "commands_alias": [f"вики"],
	            "description": "Запрос в Википедию",
	        },
	        {
	            "commands_alias": [f"кгс"],
	            "description": "скопировать голосовое сообщение (бот отправит скопированное вами голосовое)",
	        },
	        {
	            "commands_alias": [f"кик"],
	            "description": "Исключить пользователя из чата",
	        },
	        {
	            "commands_alias": [f"инвайт"],
	            "description": "Добавить пользователя в чат",
	        },
	        {
	            "commands_alias": [f"дел"],
	            "description": "удалить выбраное кол-во сообщений",
	        },
	        {
	            "commands_alias": [f"-бот"],
	            "description": "отключить бота для общедоступного использования (бот не будет реагировать на остальных)",
	        },
	        {
	            "commands_alias": [f"изч"],
	            "description": "отправить исчезающие сообщение",
	        },
	        {
	            "commands_alias": [f"спам"],
	            "description": "спам выбраным текстом",
	        },
	        {
	            "commands_alias": [f"+гс"],
	            "description": "сохранить голосовое",
	        },
	        {
	            "commands_alias": [f"гс"],
	            "description": "отправить сохранённое голосовое",
	        },
	        {
	            "commands_alias": [f"-гс"],
	            "description": "удалить сохранённое голосовое",
	        },
	        {
	            "commands_alias": [f"гсы"],
	            "description": "список сохранённых голосовых",
	        },
	        {
	            "commands_alias": [f"разбан"],
	            "description": "разблокировать пользователю доступ к боту",
	        },
	        {
	            "commands_alias": [f"админы"],
	            "description": "список администрации бота",
	        },
	        {
	            "commands_alias": [f"разбан_чат"],
	            "description": "разблокировать чату доступ к боту",

	        },
	        {
	            "commands_alias": ["+с, -с"],
	            "description": "открыть(закрыть) пользователю доступ к сохрам",
	        },
	        {
	            "commands_alias": ["+м, -м"],
	            "description": "открыть(закрыть) пользователю доступ к аудиозаписям",
	        },
	    ]
	}
    out = ""
    for command in commands[type_commands]:
        alias_transform = ", ".join(command['commands_alias'])
        description = command['description']
        out += f"{alias_transform} -- {description}\n"
    return out


def cmd(api, message, owner_id):
    universal_message = "\n🤡 Разработчик: [https://vk.com/tendo|Tendo Diverso]\n❤Бета тестер: [https://vk.com/alix.andr|Сашечка]"
    github = "\n❔ [vk.com/@dellivers0-komandy-tendorp|Полный список команд]"
    main_message = f"✅Команды TendoRP:\n{get_commands('public')}\n"

    if message['from_id'] == owner_id:
        main_message += f"\n❌Команды юзеров бота:\n{get_commands('private')}"
        universal_message += github

    main_message += universal_message

    api.messages.send(
        peer_id=message['peer_id'],
        random_id=0,
        message=main_message,
        reply_to=message['id']
    )