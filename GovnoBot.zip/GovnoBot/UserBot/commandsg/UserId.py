import functions
def cmd(vk, message, args):
    if len(args) == 1:
        reply = message.get('reply_message')
        user_id = message['reply_message']['from_id']
        if reply is None:
            user_id = functions.getUserId(args[1])
            return
        
        user_info = vk.users.get(user_ids=user_id, fields='sex, bdate, city, country, photo_max, followers_count, online, status, is_closed, friend_status, count_friends')
        info_text = f"Имя: {user_info[0]['first_name']} {user_info[0]['last_name']}\n"
        info_text += f"ID: {user_info[0]['id']}\n"
        if 'sex' in user_info[0]:
            if user_info[0]['sex'] == 1:
                info_text += "👩Пол: женский\n"
            elif user_info[0]['sex'] == 2:
                info_text += "👱Пол: мужской\n"
        if 'bdate' in user_info[0]:
            info_text += f"📅Дата рождения: {user_info[0]['bdate']}\n"
        if 'city' in user_info[0]:
            info_text += f"🌆Город: {user_info[0]['city']['title']}\n"
        if 'country' in user_info[0]:
            info_text += f"🏳️Страна: {user_info[0]['country']['title']}\n"
        if 'followers_count' in user_info[0]:
            info_text += f"📖Количество подписчиков: {user_info[0]['followers_count']}\n"
        if 'count_friends' in user_info[0]:
            info_text += f"🫂Количество друзей: {user_info[0]['count_friends']}\n"
        if 'is_closed' in user_info[0]:
            if user_info[0]['is_closed']:
                info_text += "❌Профиль закрыт\n"
            else:
                info_text += "✅Профиль открыт\n"
        if 'status' in user_info[0]:
            info_text += f"📖Статус: {user_info[0]['status']}\n"
        if 'friend_status' in user_info[0]:
            if user_info[0]['friend_status'] == 3:
                info_text += "♥Друзья\n"
            elif user_info[0]['friend_status'] == 2:
                info_text += "♥Друзья\n"
            elif user_info[0]['friend_status'] == 1:
                info_text += "🫡Подписаны друг на друга\n"
            elif user_info[0]['friend_status'] == 0:
                info_text += "🤡Не друзья\n"
        if info_text != "":
            vk.messages.send(
                peer_id=message["peer_id"],
                message="✅Информация о пользователе" + "\n" + info_text,
                random_id=0
            )
        else:
            vk.messages.edit(
                peer_id=message["peer_id"],
                message_id=message["id"],
                message="❌Информация о пользователе недоступна",
                random_id=0
            )
    else:
        vk.messages.send(
            peer_id=message["peer_id"],
            message=f'❌Правильное использование команды: {config.prefix}инфо',
            random_id=0
            )
