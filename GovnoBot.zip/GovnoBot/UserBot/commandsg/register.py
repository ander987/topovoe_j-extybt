def cmd(vk, message, args):
    vk.messages.send(
        peer_id=message['peer_id'],
        random_id=0,
        message=f"✅Для установки бота на аккаунт напишите [https://vk.com/tendo|Tendo Diverso]\nЦена подписки на бота навсегда - 199р"
        )