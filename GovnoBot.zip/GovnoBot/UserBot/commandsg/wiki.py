import wikipedia
def cmd(vk, message, args):
    text = " ".join(args[1:])
    page = wikipedia.page(text)
    wikipedia.set_lang('ru')
    
    if len(args) < 2:
        vk.messages.edit( 
        peer_id=message["peer_id"],  
        message_id=message["id"],  
        message=f'❌Правильное использование команды вики "запрос"'
            )
        
    if len(args) >= 2:
        vk.messages.send( 
            peer_id=message["peer_id"],  
            random_id=0,  
            message=f'🗯Получаю информацию из Википедии...️'
            )
        vk.messages.send( 
            peer_id=message["peer_id"],  
            random_id=0,  
            message=f'✅Результат поиска по запросу "{text}":\n{page.summary}'
            )
    if args[1] == "Tendo":
    	vk.messages.send( 
            peer_id=message["peer_id"],  
            random_id=0,  
            message=f'✅Результат поиска по запросу "Tendo":\nTendo Diverso - Владелец/разработчик юзер бота ВКонтакте под названием TendoRP'
            )