tokens = ["Токен ВКонтакте"]
access_token = "Токен сообщества"
log_messages = False

prefixes = {  
    "error": "❗",  
    "invalid": "⚠️",  
    "process": "⚡",  
    "success": "✅",
    "success_no": "❎"  
}

odeanon_token = True

admins = [Числовой айди разработчика]
sp = []
gpt = "Токен ChatGPT"
status = True