



token = "6654752067:AAFpd04v9JAfF5bpQLMsJUrFaPhxDFAERAo"
idadmin = "5606138180"

qiwinumber = 79085465680
token_qiwi='ba7c0ee86247dece3f5bb77ae915fdd6' 

cena = 10


oplatil = "✅Заказ оплачен!\nПришлите ваш токен в чат"
neoplatil = "Вы не оплатили заказ"  


otvetstart="Приветствуем!\nТут вы можете купить доступ к TendoRP."
