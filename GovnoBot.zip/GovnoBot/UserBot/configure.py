config = {
	'name': 'TendoRP_Buy',
	'token': '6654752067:AAFpd04v9JAfF5bpQLMsJUrFaPhxDFAERAo',
	'tokenqiwi': 'ba7c0ee86247dece3f5bb77ae915fdd6',
	'phoneqiwi': '+79085465680'
}