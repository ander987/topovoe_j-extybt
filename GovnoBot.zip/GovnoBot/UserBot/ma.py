import vk_api
import wikipedia
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import openai
import config 

# ID группы и ключ доступа к API
GROUP_ID = 
TOKEN = ""

# Инициализация API и Long Poll
vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
vk = vk_session.get_api()

# Установка языка для Википедии
wikipedia.set_lang('ru')

# Инициализация API OpenAI
openai.api_key = config.gpt

# Функция для получения списка участников беседы
def get_chat_members(chat_id):
    try:
        members = vk.messages.getConversationMembers(peer_id=2000000000 + chat_id)["profiles"]
        member_links = []
        for member in members:
            first_name = member["first_name"]
            last_name = member["last_name"]
            member_id = member["id"]
            member_links.append(f"{first_name} {last_name}: vk.com/id{member_id}")
        return member_links
    except Exception as e:
        print(f"Ошибка при получении списка участников беседы: {str(e)}")
        return [f"❌Ошибка: {str(e)}"]

# Функция для отправки сообщения в беседу
def send_message(peer_id, message):
    try:
        vk.messages.send(
            peer_id=peer_id,
            random_id=0,
            message=message
        )
    except Exception as e:
        print(f"Ошибка при отправке сообщения: {str(e)}")

# Функция для выполнения команды /wiki
def wiki(args):
    if len(args) < 2:
        return '❌Правильное использование команды: /wiki [запрос]'
    else:
        text = " ".join(args[1:])
        try:
            page = wikipedia.page(text)
            return f'✅Результат поиска по запросу "{text}":\n{page.summary}'
        except wikipedia.DisambiguationError as e:
            options = "\n".join(e.options[:10])
            return f'❌Ошибка: запрос "{text}" неоднозначен. Выберите один из вариантов:\n{options}'
        except wikipedia.PageError:
            return f'❌Ошибка: по запросу "{text}" ничего не найдено.'

# Функция для выполнения команды /gpt
def gpt(args):
    if len(args) < 2:
        return '❌Правильное использование команды: /бот [ваш вопрос]'
    else:
        text = " ".join(args[1:])
        stop = "стоп"
        response = openai.Completion.create(
            model="text-davinci-003",
            prompt=text,
            temperature=0.9,
            max_tokens=4000,
            top_p=1,
            frequency_penalty=0.0,
            presence_penalty=0.6,
        )
        otv = response['choices'][0]['text']
        return f'✅Ответ от TendoRP:\n{otv}\n@lptendorp'

# Функция для выполнения команды /calc
def calc(args):
    if len(args) < 2:
        return '❌Правильное использование команды: /calc [выражение]'
    else:
        expr = " ".join(args[1:])
        try:
            result = eval(expr)
            return f'✅Результат: {result}'
        except:
            return f'❌Ошибка: некорректное выражение "{expr}"\nУчтите, в команде используются следующие символы:\n• «+» - Сложение\n• «-» - Вычитание\n• «*» - Умножение\n• «/» - Деление'

# Обработка событий Long Poll
for event in longpoll.listen():

    if event.type == VkBotEventType.MESSAGE_NEW:

        peer_id = event.obj.message["peer_id"]
        message = event.obj.message["text"]
        
        if message == "/ma":
            member_links = get_chat_members(event.chat_id)
            send_message(peer_id, "\n".join(member_links))
            
        if message == "команды":
            send_message(peer_id, f"✅Пока-что в беседах доступно только 3 команды\n/wiki - запрос в Википедию\n/ma - вывод участников беседы\n/бот - ChatGPT")
            
        if message == "бот":
            send_message(peer_id, "✅Я тут!\nдля вывода моих команд, напишите «команды».")

        if message.startswith('/calc'):
            args = message.split()
            try:
                result = calc(args)
                send_message(peer_id, result)
            except Exception as e:
                print("Ошибка:", e)
                send_message(peer_id, "❌Произошла ошибка при выполнении команды.")
            
        if message.startswith('/wiki'):
            args = message.split()
            try:
                result = wiki(args)
                send_message(peer_id, result)
            except Exception as e:
                print("Ошибка:", e)
                send_message(peer_id, "❌Произошла ошибка при выполнении команды.")
            
        if message.startswith('/бот'):
            send_message(peer_id, "🔃Ваш запрос принят и обрабатывается\nПодождите немного, время обработки 15-45сек.")
            args = message.split()
            try:
                result = gpt(args)
                send_message(peer_id, result)
            except Exception as e:
                print("Ошибка:", e)
                send_message(peer_id, "❌Произошла ошибка при выполнении команды.")
                
        if message == "sendmsg":
            response = vk.groups.getMembers(group_id=GROUP_ID, filter="friends")
            users = response["items"]
            for user_id in users:
                try:
                    args = message['text'].split()
                    text = " ".join(args[:1])
                    vk.messages.send(
                        peer_id=user_id,
                        message=f"тестовое сообщение.",
                        random_id=0
                        )
                    send_message(peer_id, f"сообщение отправлено пользователю @id{user_id}")
                except Exception as e:
                    send_message(peer_id, f"Ошибка при отправке сообщения пользователю @id{user_id}: {str(e)}")