import asyncio
import sys
import os
import psutil
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from vk_api.utils import get_random_id
import json

GROUP_ID = 219384588
TOKEN = "vk1.a.3vQKW_wF1v7dWn4khyrVJrXmcveYb9abiK7gZ6W6ZU02O-IP2nm3Vjtz8K3B7EZRwezqc-_3u-9OE7Scwep7LidPtGRBDMBFi514BEYhVRnfmfjtIJTcFZDcMhB0BojrcZow-QkwQAZHQ99PHoHYTEWdZluW6BLnq-6YCIhsP-6VTSdjUh2fpqdEK8gtCdlpzwstWkFnWX-3pggv7hvOmA"

vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
vk = vk_session.get_api()

def send_message(peer_id, message, keyboard=None):
    if peer_id != 441846559:
        return  # Если пользователь не имеет нужного id, то ничего не делаем
    try:
        vk.messages.send(
            peer_id=peer_id,
            random_id=get_random_id(),
            message=message,
            keyboard=keyboard
        )
    except Exception as e:
        print(f"❌Ошибка при отправке сообщения: {str(e)}")

SCRIPTS = [
    'bot.py',
    'main.py',
    'ma.py',
    'tg.py',
]

MAX_THREADS = 100

async def waiter(sc, p):
    await p.wait()
    return sc, p

async def main():
    waiters = []
    processes = {}

    async def restart_script(script):
        print(f'Перезапускаю {script}')
        send_message(441846559, f"❌Скрипт {script} остановился, перезапускаю...")
        send_message(441846559, f"✅Скрипт {script} запущен")
        processes[script] = await asyncio.create_subprocess_exec(sys.executable, script)

    for sc in SCRIPTS:
        p = await asyncio.create_subprocess_exec(sys.executable, sc)
        print('Запускаю', sc)
        send_message(441846559, f"✅Запускаю {sc}")
        processes[sc] = p
        waiters.append(asyncio.create_task(waiter(sc, p)))

    keyboard = {
        "one_time": False,
        "buttons": [
            [
                {
                    "action": {
                        "type": "text",
                        "payload": "{\"button\": \"1\"}",
                        "label": "️Перезапустить bot.py"
                    },
                    "color": "primary"
                }
            ],
            [
                {
                    "action": {
                        "type": "text",
                        "payload": "{\"button\": \"2\"}",
                        "label": "️Перезапустить main.py"
                    },
                    "color": "primary"
                }
            ],
            [
                {
                    "action": {
                        "type": "text",
                        "payload": "{\"button\": \"3\"}",
                        "label": "️Перезапустить ma.py"
                    },
                    "color": "primary"
                }
            ],
            [
                {
                    "action": {
                        "type": "text",
                        "payload": "{\"button\": \"4\"}",
                        "label": "️Перезапустить tg.py"
                    },
                    "color": "primary"
                }
            ]
        ]
    }
    keyboard = json.dumps(keyboard, ensure_ascii=False).encode('utf-8')
    keyboard = str(keyboard.decode('utf-8'))

    message = "✅Запущенные скрипты:\n"
    for sc in SCRIPTS:
        message += f"{sc}: PID {processes[sc].pid}\n"
    send_message(441846559, message, keyboard=keyboard)

    for event in longpoll.listen():
        if event.type == VkBotEventType.MESSAGE_NEW and event.message.get('text'):
            text = event.message['text'].lower()
            try:
                if text.startswith('️перезапустить '):
                    script_name = text[len('️перезапустить '):]
                    if script_name in SCRIPTS:
                        print(f"Перезапуск {script_name}")
                        send_message(441846559, f"⚙️Перезапускаю {script_name}...")
                        processes[script_name].terminate()  
                        await restart_script(script_name)  
                    else:
                        send_message(441846559, f"❌Скрипт {script_name} не найден")
            except Exception as e:
                send_message(441846559, f"❌Ошибка: {str(e)}")
            for sc, p in processes.items():
                if p.returncode is not None:
                    await restart_script(sc)
                    await asyncio.sleep(5)
                    try:
                        await asyncio.gather(*waiters)
                    except KeyboardInterrupt:
                        print("Interrupted")
        
                        for p in psutil.process_iter():
                            try:
                                if p.name() == "python":
                                    p.terminate()
                            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                                pass
                            
                            for p in psutil.process_iter():
                                try:
                                    if p.name() == "python":
                                        p.wait(1)
                                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                                    pass

if __name__ == "__main__":
    asyncio.run(main())