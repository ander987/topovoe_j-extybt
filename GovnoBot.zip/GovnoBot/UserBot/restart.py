import vk_api
import wikipedia
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from db import vkdb

GROUP_ID = 219384588
TOKEN = "vk1.a.AnwrQm7SR3UI2Sbozr0irUqJAoU9PoJ4y0Uk1E1BkwVNEizuBL0TqE1Mg_UoMhaHcMYlFI5hVSOEk5Z3hMhgAzC8e1kgkkw1Wm7s342mh0lWD_Z1TBgbEbfNHGy0CRADCRSyiUwhrkPIlLAQkUX3KPqIGCeuifN-0qsZjyZqNfGaO6hz13QEViH6ivbnE11jvE_680rQXjBxtaX2-QPYnQ"

vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
vk = vk_session.get_api()

data = vkdb("tokens.json")
data_admins = vkdb("admins.json")
hate = vkdb("hate.json")
profiles = vkdb("profiles.json")
ignore = vkdb("ignore.json")
qiwi = vkdb("qiwi.json")
audio = vkdb("audio.json")
tim = vkdb("tim.json")


tokens = data.get()

hate_info = hate.get()
info = data.get()
admins = data_admins.get()
ignore_info = ignore.get()
qiwi_info = qiwi.get()
audio_info = audio.get()
tim_info = tim.get()

owner_id = vk.users.get()[0]['id']
prefix = "/"
message = vk.messages.getById(message_ids=event.message_id)['items'][0]
args = message['text'].replace(prefix, "", 1).split()
command = args[0]

user_id = message['id']

class Userbot():
    if command == "старт":
        token = [i for i in list(info) if info[i]["owner_id"] == user_id][0]
        if data.delete(token):
            hate.delete(token)
            profiles.delete(token)
            qiwi.delete(token)
            ignore.delete(token)
            qiwi.delete(token)
            audio.delete(token)
            tim.delete(token)
            
        tok = args[1].split('=')[1].split('&')[0]
        delta = timedelta(hours=3)
        registration = datetime.datetime.now() + delta
        formatted_registration = registration.strftime("%d.%m.%Y")
        
        profiles.set(tok, {"owner_id": user_id, "uses_commands": 0, "user_type": None, "token": None, "registration": formatted_registration, "active": 1, "status": False, "prefix": "/"})
        
        data.set(tok, {"ban_users": [], "ban_chats": [], "disabled": False, "saved_audio": {}, "owner_id": user_id})
        
        ignore.set(tok, {"ignore": []})
        
        qiwi.set(tok, {"num": "Не указан", "tok": "Не указан", "sum": "Не указана", "pay": "Не указана"})
        
        tim.set(tok, {"text": {}, "media": {}, "chat": {}})
        
        Userbot(tok).start()
        
        

