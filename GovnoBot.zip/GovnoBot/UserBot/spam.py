import vk_api
import wikipedia
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
from random import choice

# ID группы и ключ доступа к API
GROUP_ID = 219384588
TOKEN = "vk1.a.3vQKW_wF1v7dWn4khyrVJrXmcveYb9abiK7gZ6W6ZU02O-IP2nm3Vjtz8K3B7EZRwezqc-_3u-9OE7Scwep7LidPtGRBDMBFi514BEYhVRnfmfjtIJTcFZDcMhB0BojrcZow-QkwQAZHQ99PHoHYTEWdZluW6BLnq-6YCIhsP-6VTSdjUh2fpqdEK8gtCdlpzwstWkFnWX-3pggv7hvOmA"
hate = open("hate.txt", "r", encoding="utf-8").read().split("\n")

# Инициализация API и Long Poll
vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
vk = vk_session.get_api()

for event in longpoll.listen():
    if event.type == VkBotEventType.MESSAGE_NEW:
        peer_id = event.obj.message["peer_id"]
        message = event.obj.message["text"]
        
        if message == "/spam":
                vk.messages.send(
                    peer_id=message["peer_id"],
                    message="Запускаю!",
                    random_id=0
                    )
                while True:
                    vk.messages.send(
                        peer_id=message["peer_id"],
                        message=choice(hate),
                        random_id=0
                        )