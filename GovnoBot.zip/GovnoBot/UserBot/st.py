import asyncio
import sys
import os
import psutil
import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import requests

GROUP_ID = 219384588
TOKEN = "vk1.a.AnwrQm7SR3UI2Sbozr0irUqJAoU9PoJ4y0Uk1E1BkwVNEizuBL0TqE1Mg_UoMhaHcMYlFI5hVSOEk5Z3hMhgAzC8e1kgkkw1Wm7s342mh0lWD_Z1TBgbEbfNHGy0CRADCRSyiUwhrkPIlLAQkUX3KPqIGCeuifN-0qsZjyZqNfGaO6hz13QEViH6ivbnE11jvE_680rQXjBxtaX2-QPYnQ"

vk_session = vk_api.VkApi(token=TOKEN)
longpoll = VkBotLongPoll(vk_session, GROUP_ID)
vk = vk_session.get_api()

def send_message(peer_id, message, keyboard=None):
    try:
        vk.messages.send(
            peer_id=441846559,
            random_id=0,
            message=message
        )
    except Exception as e:
        print(f"❌Ошибка при отправке сообщения: {str(e)}")

SCRIPTS = [
    'main.py',
    'bot.py',
    ]

MAX_THREADS = 2
send_message(441846559, f"✅Начался запуск бота")

async def waiter(sc, p):
    await p.wait()
    return sc, p

async def main():
    waiters = []
    processes = {}

    async def restart_script(script):
        print(f'Перезапускаю {script}')
        send_message(441846559, f"❌Скрипт {script} остановился, перезапускаю...")
        processes[script] = await asyncio.create_subprocess_exec(sys.executable, script)

    for sc in SCRIPTS:
        p = await asyncio.create_subprocess_exec(sys.executable, sc)
        print('Запускаю', sc)
        send_message(441846559, f"✅Запускаю {sc}")
        processes[sc] = p
        waiters.append(asyncio.create_task(waiter(sc, p)))

    while True:
        for sc, p in processes.items():
            if p.returncode is not None:
                await restart_script(sc)

        await asyncio.sleep(5)

    try:
        await asyncio.gather(*waiters)
    except KeyboardInterrupt:
        print("Interrupted")
        for p in psutil.process_iter():
            try:
                if p.name() == "python":
                    p.terminate()
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass

        # Wait for processes to terminate
        for p in psutil.process_iter():
            try:
                if p.name() == "python":
                    p.wait(1)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass

if __name__ == "__main__":
    asyncio.run(main())