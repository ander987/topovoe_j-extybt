import subprocess
import vk_api
from vk_api.longpoll import VkLongPoll, VkEventType

# Функция для замера пинга сервера
def ping(host):
    # Выполнение команды ping с помощью subprocess
    process = subprocess.Popen(['ping', '-c', '1', host], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = process.communicate()

    # Проверка результатов выполнения команды
    if process.returncode == 0:
        # Получение времени ответа от сервера
        time_index = stdout.find(b'time=')
        if time_index != -1:
            time_start = time_index + len(b'time=')
            time_end = stdout.find(b' ms', time_start)
            time = stdout[time_start:time_end]
            return f'Ping до {host}: {time.decode()} мс'
        else:
            return f'Не удалось получить время ответа от {host}'
    else:
        return f'{host} недоступен'

# Авторизация в группе ВКонтакте
vk_session = vk_api.VkApi(token='vk1.a.3vQKW_wF1v7dWn4khyrVJrXmcveYb9abiK7gZ6W6ZU02O-IP2nm3Vjtz8K3B7EZRwezqc-_3u-9OE7Scwep7LidPtGRBDMBFi514BEYhVRnfmfjtIJTcFZDcMhB0BojrcZow-QkwQAZHQ99PHoHYTEWdZluW6BLnq-6YCIhsP-6VTSdjUh2fpqdEK8gtCdlpzwstWkFnWX-3pggv7hvOmA')
vk = vk_session.get_api()
longpoll = VkLongPoll(vk_session)

# Обработка сообщений
for event in longpoll.listen():
    if event.type == VkEventType.MESSAGE_NEW and event.to_me:
        if event.text.lower().startswith('пинг'):
            # Получение IP-адреса из сообщения
            host = event.text.split(' ')[1]

            # Замер пинга и отправка сообщения с результатом
            message = ping(host)
            vk.messages.send(peer_id=event.peer_id, message=message, random_id=0)