import openai
import telebot
import config

bot = telebot.TeleBot("6286001803:AAHfPuUSIOuhVNiunu9fOd7zvlts4PbO8fQ")

@bot.message_handler(func=lambda _: True)

def handle_message(message):
    if message.text == "/start":
        bot.send_message(chat_id=message.from_user.id, text="Привет! Я - твой личный помощник в написании кода и ответы на твои вопросы. С моей помощью ты сможешь справиться с любыми задачами и достичь новых высот в программировании. Давай работать вместе и создавать потрясающие проекты!\nПока-что я нахожусь на стадии разработки, но это временно)")
    
    else:
        try:
            bot.send_message(chat_id=message.from_user.id, text="🔃Обрабатываю ваш запрос...")
            openai.api_key = config.gpt
            response = openai.Completion.create(
            model="text-davinci-003",
            prompt=message.text,
            temperature=0.5,
            max_tokens=4000,
            top_p=1.0,
            frequency_penalty=0.5,
            presence_penalty=0.0,
            )
    
            bot.send_message(chat_id=message.from_user.id, text=response['choices'][0]['text'])
        except Exception as e:
        	bot.send_message(chat_id=message.from_user.id, text=f"❌Ошибка {str(e)}")

bot.polling()